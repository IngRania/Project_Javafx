package com.example.raniaforum.Backend.Services;

import com.example.raniaforum.Backend.Models.Category;
import com.example.raniaforum.Backend.Models.Forum;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ForumServiceTest {

    @Mock
    private Connection mockConnection; // As DatabaseConnection.getConnection is static

    @Mock
    private PreparedStatement mockPreparedStatement;

    @Mock
    private ResultSet mockResultSet;

    @InjectMocks
    private ForumService forumService;

    private Forum sampleForum;
    private Category sampleCategory;
    private LocalDateTime now;

    @org.junit.jupiter.api.BeforeEach
    void setUp() throws Exception {
        now = LocalDateTime.now();

        sampleCategory = new Category();
        sampleCategory.setId(1);
        sampleCategory.setName("Test Category");

        sampleForum = new Forum();
        sampleForum.setId(1);
        sampleForum.setTitle("Test Forum");
        sampleForum.setContent("Test Content");
        sampleForum.setImagePath("test/forum_image.png");
        sampleForum.setCreatedAt(now);
        sampleForum.setCategory(sampleCategory);

        when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
        when(mockConnection.prepareStatement(anyString(), anyInt())).thenReturn(mockPreparedStatement);
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockPreparedStatement.getGeneratedKeys()).thenReturn(mockResultSet);
    }

    @Test
    void testCreateForum() throws Exception {
        // Arrange
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt(1)).thenReturn(sampleForum.getId());

        // Act
        Forum createdForum = forumService.create(sampleForum);

        // Assert
        assertNotNull(createdForum);
        assertEquals(sampleForum.getId(), createdForum.getId());
        verify(mockPreparedStatement).setString(1, sampleForum.getTitle());
        verify(mockPreparedStatement).setString(2, sampleForum.getContent());
        verify(mockPreparedStatement).setString(3, sampleForum.getImagePath());
        verify(mockPreparedStatement).setInt(4, sampleForum.getCategory().getId());
        verify(mockPreparedStatement).executeUpdate();
    }

    @Test
    void testFindById() throws Exception {
        // Arrange
        when(mockResultSet.next()).thenReturn(true).thenReturn(false);
        when(mockResultSet.getInt("id")).thenReturn(sampleForum.getId());
        when(mockResultSet.getString("title")).thenReturn(sampleForum.getTitle());
        when(mockResultSet.getString("content")).thenReturn(sampleForum.getContent());
        when(mockResultSet.getString("image_path")).thenReturn(sampleForum.getImagePath());
        when(mockResultSet.getTimestamp("created_at")).thenReturn(Timestamp.valueOf(now));
        when(mockResultSet.getInt("category_id")).thenReturn(sampleCategory.getId());
        when(mockResultSet.getString("category_name")).thenReturn(sampleCategory.getName());

        // Act
        Forum foundForum = forumService.findById(1);

        // Assert
        assertNotNull(foundForum);
        assertEquals(sampleForum.getId(), foundForum.getId());
        assertNotNull(foundForum.getCategory());
        assertEquals(sampleCategory.getId(), foundForum.getCategory().getId());
        verify(mockPreparedStatement).setInt(1, 1);
        verify(mockPreparedStatement).executeQuery();
    }

    @Test
    void testFindAll() throws Exception {
        // Arrange
        when(mockResultSet.next()).thenReturn(true).thenReturn(false);
        when(mockResultSet.getInt("id")).thenReturn(sampleForum.getId());
        when(mockResultSet.getString("title")).thenReturn(sampleForum.getTitle());
        when(mockResultSet.getString("content")).thenReturn(sampleForum.getContent());
        when(mockResultSet.getString("image_path")).thenReturn(sampleForum.getImagePath());
        when(mockResultSet.getTimestamp("created_at")).thenReturn(Timestamp.valueOf(now));
        when(mockResultSet.getInt("category_id")).thenReturn(sampleCategory.getId());
        when(mockResultSet.getString("category_name")).thenReturn(sampleCategory.getName());

        // Act
        List<Forum> foundForums = forumService.findAll();

        // Assert
        assertNotNull(foundForums);
        assertFalse(foundForums.isEmpty());
        assertEquals(1, foundForums.size());
        verify(mockPreparedStatement).executeQuery();
    }

    @Test
    void testFindByCategory() throws Exception {
        // Arrange
        when(mockResultSet.next()).thenReturn(true).thenReturn(false);
        when(mockResultSet.getInt("id")).thenReturn(sampleForum.getId());
        when(mockResultSet.getString("title")).thenReturn(sampleForum.getTitle());
        when(mockResultSet.getString("content")).thenReturn(sampleForum.getContent());
        when(mockResultSet.getString("image_path")).thenReturn(sampleForum.getImagePath());
        when(mockResultSet.getTimestamp("created_at")).thenReturn(Timestamp.valueOf(now));
        when(mockResultSet.getInt("category_id")).thenReturn(sampleCategory.getId());
        when(mockResultSet.getString("category_name")).thenReturn(sampleCategory.getName());

        // Act
        List<Forum> foundForums = forumService.findByCategory(sampleCategory.getId());

        // Assert
        assertNotNull(foundForums);
        assertFalse(foundForums.isEmpty());
        assertEquals(1, foundForums.size());
        verify(mockPreparedStatement).setInt(1, sampleCategory.getId());
        verify(mockPreparedStatement).executeQuery();
    }

    @Test
    void testUpdateForum() throws Exception {
        // Arrange
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);

        // Act
        Forum updatedForum = forumService.update(sampleForum);

        // Assert
        assertNotNull(updatedForum);
        assertEquals(sampleForum.getTitle(), updatedForum.getTitle());
        verify(mockPreparedStatement).setString(1, sampleForum.getTitle());
        verify(mockPreparedStatement).setString(2, sampleForum.getContent());
        verify(mockPreparedStatement).setString(3, sampleForum.getImagePath());
        verify(mockPreparedStatement).setInt(4, sampleForum.getCategory().getId());
        verify(mockPreparedStatement).setInt(5, sampleForum.getId());
        verify(mockPreparedStatement).executeUpdate();
    }

    @Test
    void testDeleteForum() throws Exception {
        // Arrange
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);

        // Act
        forumService.delete(1);

        // Assert
        verify(mockPreparedStatement).setInt(1, 1);
        verify(mockPreparedStatement).executeUpdate();
    }

    @Test
    void testSearchByTitle() throws Exception {
        // Arrange
        String keyword = "Test";
        when(mockResultSet.next()).thenReturn(true).thenReturn(false);
        when(mockResultSet.getInt("id")).thenReturn(sampleForum.getId());
        when(mockResultSet.getString("title")).thenReturn(sampleForum.getTitle());
        when(mockResultSet.getString("content")).thenReturn(sampleForum.getContent());
        when(mockResultSet.getString("image_path")).thenReturn(sampleForum.getImagePath());
        when(mockResultSet.getTimestamp("created_at")).thenReturn(Timestamp.valueOf(now));
        when(mockResultSet.getInt("category_id")).thenReturn(sampleCategory.getId());
        when(mockResultSet.getString("category_name")).thenReturn(sampleCategory.getName());

        // Act
        List<Forum> foundForums = forumService.searchByTitle(keyword);

        // Assert
        assertNotNull(foundForums);
        assertFalse(foundForums.isEmpty());
        assertEquals(1, foundForums.size());
        verify(mockPreparedStatement).setString(1, "%" + keyword + "%");
        verify(mockPreparedStatement).executeQuery();
    }

    @Test
    void testSortByDate() throws Exception {
        // Arrange
        // Mocking for the first call (e.g. ASC)
        when(mockResultSet.next()).thenReturn(true).thenReturn(false) // For ASC call
                .thenReturn(true).thenReturn(false); // For DESC call, if executeQuery is called again with same
                                                     // mockResultSet
        when(mockResultSet.getInt("id")).thenReturn(sampleForum.getId());
        when(mockResultSet.getString("title")).thenReturn(sampleForum.getTitle());
        when(mockResultSet.getString("content")).thenReturn(sampleForum.getContent());
        when(mockResultSet.getString("image_path")).thenReturn(sampleForum.getImagePath());
        when(mockResultSet.getTimestamp("created_at")).thenReturn(Timestamp.valueOf(now));
        when(mockResultSet.getInt("category_id")).thenReturn(sampleCategory.getId());
        when(mockResultSet.getString("category_name")).thenReturn(sampleCategory.getName());

        when(mockConnection.prepareStatement(contains("ORDER BY f.created_at ASC"))).thenReturn(mockPreparedStatement);
        when(mockConnection.prepareStatement(contains("ORDER BY f.created_at DESC"))).thenReturn(mockPreparedStatement);

        // Act
        List<Forum> sortedForumsAsc = forumService.sortByDate(true);
        List<Forum> sortedForumsDesc = forumService.sortByDate(false);

        // Assert
        assertNotNull(sortedForumsAsc);
        assertFalse(sortedForumsAsc.isEmpty());
        assertNotNull(sortedForumsDesc);
        assertFalse(sortedForumsDesc.isEmpty());
        verify(mockConnection).prepareStatement(contains("ORDER BY f.created_at ASC"));
        verify(mockConnection).prepareStatement(contains("ORDER BY f.created_at DESC"));
        verify(mockPreparedStatement, times(2)).executeQuery(); // Called for ASC and DESC
    }
}
