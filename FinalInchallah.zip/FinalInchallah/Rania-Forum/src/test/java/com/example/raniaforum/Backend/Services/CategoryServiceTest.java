package com.example.raniaforum.Backend.Services;

import com.example.DatabaseConnection;
import com.example.raniaforum.Backend.Models.Category;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class CategoryServiceTest {

    @Mock
    private Connection mockConnection;

    @Mock
    private PreparedStatement mockPreparedStatement;

    @Mock
    private ResultSet mockResultSet;

    @InjectMocks
    private CategoryService categoryService;

    private Category sampleCategory;

    @BeforeEach
    void setUp() throws SQLException {
        MockitoAnnotations.openMocks(this);
        sampleCategory = new Category();
        sampleCategory.setId(1);
        sampleCategory.setName("Test Category");
        sampleCategory.setDescription("Test Description");
        sampleCategory.setCreatedAt(LocalDateTime.now());

        // Mock static method DatabaseConnection.getConnection()
        // This requires org.mockito:mockito-inline dependency
        // Ensure it's added to your pom.xml or build.gradle
    }

    @Test
    void findAll() throws SQLException {
        try (MockedStatic<DatabaseConnection> mockedStatic = Mockito.mockStatic(DatabaseConnection.class)) {
            mockedStatic.when(DatabaseConnection::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);

            when(mockResultSet.next()).thenReturn(true).thenReturn(false); // Simulate one row
            when(mockResultSet.getInt("id")).thenReturn(sampleCategory.getId());
            when(mockResultSet.getString("name")).thenReturn(sampleCategory.getName());
            when(mockResultSet.getString("description")).thenReturn(sampleCategory.getDescription());
            when(mockResultSet.getTimestamp("created_at")).thenReturn(Timestamp.valueOf(sampleCategory.getCreatedAt()));

            List<Category> categories = categoryService.findAll();

            assertNotNull(categories);
            assertEquals(1, categories.size());
            assertEquals(sampleCategory.getName(), categories.get(0).getName());

            verify(mockConnection).prepareStatement("SELECT * FROM category");
            verify(mockPreparedStatement).executeQuery();
        }
    }

    @Test
    void findById() throws SQLException {
        try (MockedStatic<DatabaseConnection> mockedStatic = Mockito.mockStatic(DatabaseConnection.class)) {
            mockedStatic.when(DatabaseConnection::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);

            when(mockResultSet.next()).thenReturn(true);
            when(mockResultSet.getInt("id")).thenReturn(sampleCategory.getId());
            when(mockResultSet.getString("name")).thenReturn(sampleCategory.getName());
            when(mockResultSet.getString("description")).thenReturn(sampleCategory.getDescription());
            when(mockResultSet.getTimestamp("created_at")).thenReturn(Timestamp.valueOf(sampleCategory.getCreatedAt()));

            Category foundCategory = categoryService.findById(sampleCategory.getId());

            assertNotNull(foundCategory);
            assertEquals(sampleCategory.getName(), foundCategory.getName());

            verify(mockConnection).prepareStatement("SELECT * FROM category WHERE id = ?");
            verify(mockPreparedStatement).setInt(1, sampleCategory.getId());
            verify(mockPreparedStatement).executeQuery();
        }
    }

    @Test
    void findById_NotFound() throws SQLException {
        try (MockedStatic<DatabaseConnection> mockedStatic = Mockito.mockStatic(DatabaseConnection.class)) {
            mockedStatic.when(DatabaseConnection::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
            when(mockResultSet.next()).thenReturn(false); // Simulate no row found

            Category foundCategory = categoryService.findById(999); // Non-existent ID

            assertNull(foundCategory);

            verify(mockConnection).prepareStatement("SELECT * FROM category WHERE id = ?");
            verify(mockPreparedStatement).setInt(1, 999);
            verify(mockPreparedStatement).executeQuery();
        }
    }

    @Test
    void create() throws SQLException {
        try (MockedStatic<DatabaseConnection> mockedStatic = Mockito.mockStatic(DatabaseConnection.class)) {
            mockedStatic.when(DatabaseConnection::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString(), eq(PreparedStatement.RETURN_GENERATED_KEYS)))
                    .thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeUpdate()).thenReturn(1); // Simulate one row affected
            when(mockPreparedStatement.getGeneratedKeys()).thenReturn(mockResultSet);
            when(mockResultSet.next()).thenReturn(true);
            when(mockResultSet.getInt(1)).thenReturn(sampleCategory.getId());

            Category newCategory = new Category();
            newCategory.setName("New Category");
            newCategory.setDescription("New Description");

            Category createdCategory = categoryService.create(newCategory);

            assertNotNull(createdCategory);
            assertEquals(sampleCategory.getId(), createdCategory.getId()); // Assuming ID is set from generated keys
            assertEquals("New Category", createdCategory.getName());

            verify(mockConnection).prepareStatement("INSERT INTO category (name, description) VALUES (?, ?)",
                    PreparedStatement.RETURN_GENERATED_KEYS);
            verify(mockPreparedStatement).setString(1, "New Category");
            verify(mockPreparedStatement).setString(2, "New Description");
            verify(mockPreparedStatement).executeUpdate();
            verify(mockPreparedStatement).getGeneratedKeys();
        }
    }

    @Test
    void update() throws SQLException {
        try (MockedStatic<DatabaseConnection> mockedStatic = Mockito.mockStatic(DatabaseConnection.class)) {
            mockedStatic.when(DatabaseConnection::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeUpdate()).thenReturn(1); // Simulate one row affected

            Category categoryToUpdate = new Category();
            categoryToUpdate.setId(sampleCategory.getId());
            categoryToUpdate.setName("Updated Name");
            categoryToUpdate.setDescription("Updated Description");

            Category updatedCategory = categoryService.update(categoryToUpdate);

            assertNotNull(updatedCategory);
            assertEquals("Updated Name", updatedCategory.getName());

            verify(mockConnection).prepareStatement("UPDATE category SET name = ?, description = ? WHERE id = ?");
            verify(mockPreparedStatement).setString(1, "Updated Name");
            verify(mockPreparedStatement).setString(2, "Updated Description");
            verify(mockPreparedStatement).setInt(3, sampleCategory.getId());
            verify(mockPreparedStatement).executeUpdate();
        }
    }

    @Test
    void delete() throws SQLException {
        try (MockedStatic<DatabaseConnection> mockedStatic = Mockito.mockStatic(DatabaseConnection.class)) {
            mockedStatic.when(DatabaseConnection::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeUpdate()).thenReturn(1); // Simulate one row affected

            categoryService.delete(sampleCategory.getId());

            verify(mockConnection).prepareStatement("DELETE FROM category WHERE id = ?");
            verify(mockPreparedStatement).setInt(1, sampleCategory.getId());
            verify(mockPreparedStatement).executeUpdate();
        }
    }

    @Test
    void searchByName() throws SQLException {
        try (MockedStatic<DatabaseConnection> mockedStatic = Mockito.mockStatic(DatabaseConnection.class)) {
            mockedStatic.when(DatabaseConnection::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);

            when(mockResultSet.next()).thenReturn(true).thenReturn(false); // Simulate one row
            when(mockResultSet.getInt("id")).thenReturn(sampleCategory.getId());
            when(mockResultSet.getString("name")).thenReturn(sampleCategory.getName());
            when(mockResultSet.getString("description")).thenReturn(sampleCategory.getDescription());
            when(mockResultSet.getTimestamp("created_at")).thenReturn(Timestamp.valueOf(sampleCategory.getCreatedAt()));

            List<Category> categories = categoryService.searchByName("Test");

            assertNotNull(categories);
            assertEquals(1, categories.size());
            assertEquals(sampleCategory.getName(), categories.get(0).getName());

            verify(mockConnection).prepareStatement("SELECT * FROM category WHERE name LIKE ?");
            verify(mockPreparedStatement).setString(1, "%Test%");
            verify(mockPreparedStatement).executeQuery();
        }
    }

    @Test
    void sortByDate_Ascending() throws SQLException {
        try (MockedStatic<DatabaseConnection> mockedStatic = Mockito.mockStatic(DatabaseConnection.class)) {
            mockedStatic.when(DatabaseConnection::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);

            when(mockResultSet.next()).thenReturn(true).thenReturn(false); // Simulate one row
            when(mockResultSet.getInt("id")).thenReturn(sampleCategory.getId());
            when(mockResultSet.getString("name")).thenReturn(sampleCategory.getName());
            when(mockResultSet.getString("description")).thenReturn(sampleCategory.getDescription());
            when(mockResultSet.getTimestamp("created_at")).thenReturn(Timestamp.valueOf(sampleCategory.getCreatedAt()));

            List<Category> categories = categoryService.sortByDate(true); // Ascending

            assertNotNull(categories);
            assertEquals(1, categories.size());
            assertEquals(sampleCategory.getName(), categories.get(0).getName());

            verify(mockConnection).prepareStatement("SELECT * FROM category ORDER BY created_at ASC");
            verify(mockPreparedStatement).executeQuery();
        }
    }

    @Test
    void sortByDate_Descending() throws SQLException {
        try (MockedStatic<DatabaseConnection> mockedStatic = Mockito.mockStatic(DatabaseConnection.class)) {
            mockedStatic.when(DatabaseConnection::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
            when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);

            when(mockResultSet.next()).thenReturn(true).thenReturn(false); // Simulate one row
            when(mockResultSet.getInt("id")).thenReturn(sampleCategory.getId());
            when(mockResultSet.getString("name")).thenReturn(sampleCategory.getName());
            when(mockResultSet.getString("description")).thenReturn(sampleCategory.getDescription());
            when(mockResultSet.getTimestamp("created_at")).thenReturn(Timestamp.valueOf(sampleCategory.getCreatedAt()));

            List<Category> categories = categoryService.sortByDate(false); // Descending

            assertNotNull(categories);
            assertEquals(1, categories.size());
            assertEquals(sampleCategory.getName(), categories.get(0).getName());

            verify(mockConnection).prepareStatement("SELECT * FROM category ORDER BY created_at DESC");
            verify(mockPreparedStatement).executeQuery();
        }
    }

    // Exception handling tests
    @Test
    void findAll_SQLException() throws SQLException {
        try (MockedStatic<DatabaseConnection> mockedStatic = Mockito.mockStatic(DatabaseConnection.class)) {
            mockedStatic.when(DatabaseConnection::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenThrow(new SQLException("Test SQL Exception"));

            // We expect the service to catch the SQLException and return an empty list (or
            // handle as per its design)
            // And printStackTrace, which we can't directly assert here without more complex
            // setup.
            // For now, just ensure it doesn't rethrow an unhandled exception.
            List<Category> categories = categoryService.findAll();
            assertNotNull(categories);
            assertTrue(categories.isEmpty());
        }
    }

    @Test
    void findById_SQLException() throws SQLException {
        try (MockedStatic<DatabaseConnection> mockedStatic = Mockito.mockStatic(DatabaseConnection.class)) {
            mockedStatic.when(DatabaseConnection::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenThrow(new SQLException("Test SQL Exception"));

            Category category = categoryService.findById(1);
            assertNull(category);
        }
    }

    @Test
    void create_SQLException() throws SQLException {
        try (MockedStatic<DatabaseConnection> mockedStatic = Mockito.mockStatic(DatabaseConnection.class)) {
            mockedStatic.when(DatabaseConnection::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString(), anyInt()))
                    .thenThrow(new SQLException("Test SQL Exception"));

            Category newCategory = new Category();
            newCategory.setName("New Category");
            newCategory.setDescription("New Description");

            Category createdCategory = categoryService.create(newCategory);
            // ID would not be set if SQLException occurs before getting generated keys
            assertEquals(0, createdCategory.getId()); // or assertNull(createdCategory.getId()) if id is Integer
            assertEquals("New Category", createdCategory.getName()); // Name should still be set
        }
    }

    @Test
    void update_SQLException() throws SQLException {
        try (MockedStatic<DatabaseConnection> mockedStatic = Mockito.mockStatic(DatabaseConnection.class)) {
            mockedStatic.when(DatabaseConnection::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenThrow(new SQLException("Test SQL Exception"));

            Category categoryToUpdate = new Category();
            categoryToUpdate.setId(sampleCategory.getId());
            categoryToUpdate.setName("Updated Name");
            categoryToUpdate.setDescription("Updated Description");

            Category updatedCategory = categoryService.update(categoryToUpdate);
            // The method returns the input category, so its fields will be as set before
            // the call
            assertEquals("Updated Name", updatedCategory.getName());
        }
    }

    @Test
    void delete_SQLException() throws SQLException {
        try (MockedStatic<DatabaseConnection> mockedStatic = Mockito.mockStatic(DatabaseConnection.class)) {
            mockedStatic.when(DatabaseConnection::getConnection).thenReturn(mockConnection);
            when(mockConnection.prepareStatement(anyString())).thenThrow(new SQLException("Test SQL Exception"));

            // Verify that the method completes without throwing an unhandled exception
            assertDoesNotThrow(() -> categoryService.delete(sampleCategory.getId()));
        }
    }
}
