package com.example.raniaforum.Frontend.Controllers;

import com.example.raniaforum.Backend.Models.ChatMessage;
import com.example.raniaforum.Backend.Models.User;
import com.example.raniaforum.Backend.Services.ChatService;
import com.example.raniaforum.Backend.Services.UserService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.application.Platform;
import javafx.util.Callback;
import org.kordamp.ikonli.javafx.FontIcon;
import org.kordamp.ikonli.materialdesign2.MaterialDesignP;
import org.kordamp.ikonli.materialdesign2.MaterialDesignE;
import org.kordamp.ikonli.materialdesign2.MaterialDesignS;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class ChatController {

    @FXML
    private ListView<User> usersListView;
    @FXML
    private BorderPane chatPane;
    @FXML
    private ListView<ChatMessage> chatMessagesListView;
    @FXML
    private TextField messageInputArea;
    @FXML
    private Button sendMessageButton;
    @FXML
    private Button emojiButton;
    @FXML
    private Label chattingWithLabel;
    @FXML
    private Circle userStatusIndicator;

    // Add a direct reference to the new chat button
    @FXML
    private Button newChatButton;

    private ChatService chatService;
    private UserService userService;
    private User currentUser;
    private User selectedChatPartner;
    private ObservableList<User> userObservableList;
    private ObservableList<ChatMessage> observableChatMessages;
    private Timer messageRefreshTimer;
    private final DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");

    public void initialize() {
        // Setup icons programmatically
        Platform.runLater(this::setupIcons);

        chatService = new ChatService();
        userService = new UserService();
        currentUser = StaticSession.getCurrentUser();

        userObservableList = FXCollections.observableArrayList();
        usersListView.setItems(userObservableList);
        usersListView.setCellFactory(param -> new UserContactCell());

        observableChatMessages = FXCollections.observableArrayList();
        chatMessagesListView.setItems(observableChatMessages);
        chatMessagesListView.setCellFactory(param -> new ModernChatMessageCell(currentUser));

        if (currentUser == null) {
            chatPane.setDisable(true);
            usersListView.setDisable(true);
            chattingWithLabel.setText("Please log in to use chat");
            userStatusIndicator.setVisible(false);
            return;
        }

        loadUserList();
        setupUserSelectionListener();
        startMessagePolling();

        messageInputArea.setDisable(true);
        sendMessageButton.setDisable(true);
        chattingWithLabel.setText("Select a user to start chatting");
        userStatusIndicator.setVisible(false);
    }

    // Setup icons after scene is constructed
    private void setupIcons() {
        // Find new chat button in the scene once it's available
        if (chatPane.getScene() != null) {
            Button foundNewChatButton = findNewChatButton();
            if (foundNewChatButton != null) {
                FontIcon pencilIcon = new FontIcon(MaterialDesignP.PENCIL);
                pencilIcon.setIconSize(18);
                foundNewChatButton.setGraphic(pencilIcon);
            }
        }

        if (emojiButton != null) {
            FontIcon emojiIcon = new FontIcon(MaterialDesignE.EMOTICON_OUTLINE);
            emojiIcon.setIconSize(18);
            emojiButton.setGraphic(emojiIcon);
        }

        if (sendMessageButton != null) {
            FontIcon sendIcon = new FontIcon(MaterialDesignS.SEND);
            sendIcon.setIconSize(18);
            sendMessageButton.setGraphic(sendIcon);
        }
    }

    // Helper method to find the new chat button (safer implementation)
    private Button findNewChatButton() {
        try {
            if (chatPane.getScene() == null)
                return null;

            SplitPane splitPane = (SplitPane) chatPane.getScene().getRoot();
            if (splitPane.getItems().size() < 1)
                return null;

            VBox contactsPanel = (VBox) splitPane.getItems().get(0);
            if (contactsPanel.getChildren().isEmpty())
                return null;

            for (javafx.scene.Node child : contactsPanel.getChildren()) {
                if (child instanceof HBox) {
                    HBox hbox = (HBox) child;
                    for (javafx.scene.Node hboxChild : hbox.getChildren()) {
                        if (hboxChild instanceof Button
                                && ((Button) hboxChild).getStyleClass().contains("new-chat-button")) {
                            return (Button) hboxChild;
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error finding new chat button: " + e.getMessage());
        }
        return null;
    }

    @FXML
    private void handleNewChat() {
        // Placeholder for new chat functionality
        System.out.println("New chat button clicked");
    }

    private void loadUserList() {
        if (currentUser != null) {
            List<User> users = userService.getAllUsersExceptCurrent(currentUser.getId());
            userObservableList.setAll(users);
        }
    }

    private void setupUserSelectionListener() {
        usersListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            selectedChatPartner = newValue;
            if (selectedChatPartner != null) {
                chattingWithLabel.setText(selectedChatPartner.getNom());
                messageInputArea.setDisable(false);
                sendMessageButton.setDisable(false);
                userStatusIndicator.setVisible(true);
                // This is a placeholder - in a real app, you'd check actual user status
                boolean isOnline = Math.random() > 0.5; // Randomly set online status for demo
                if (isOnline) {
                    userStatusIndicator.getStyleClass().remove("offline");
                } else {
                    if (!userStatusIndicator.getStyleClass().contains("offline")) {
                        userStatusIndicator.getStyleClass().add("offline");
                    }
                }
                loadConversation();
            } else {
                chattingWithLabel.setText("Select a user to start chatting");
                messageInputArea.setDisable(true);
                sendMessageButton.setDisable(true);
                userStatusIndicator.setVisible(false);
                observableChatMessages.clear();
            }
        });
    }

    private void loadConversation() {
        if (currentUser == null || selectedChatPartner == null) {
            observableChatMessages.clear();
            return;
        }
        List<ChatMessage> messages = chatService.fetchMessagesBetweenUsers(currentUser.getId(),
                selectedChatPartner.getId());
        observableChatMessages.setAll(messages);
        scrollToBottom();
    }

    private void markMessagesAsRead(List<ChatMessage> messages) {
        if (currentUser == null || messages == null || messages.isEmpty()) {
            return;
        }
    }

    @FXML
    private void handleSendMessage() {
        if (currentUser == null || selectedChatPartner == null) {
            System.out.println("No user or chat partner selected.");
            return;
        }
        String messageText = messageInputArea.getText().trim();
        if (!messageText.isEmpty()) {
            ChatMessage newMessage = new ChatMessage();
            newMessage.setSender(currentUser);
            newMessage.setReceiver(selectedChatPartner);
            newMessage.setMessage(messageText);
            newMessage.setCreatedAt(LocalDateTime.now());

            ChatMessage sentMessage = chatService.sendMessage(newMessage);
            if (sentMessage != null) {
                messageInputArea.clear();
            } else {
                System.err.println("Failed to send message.");
            }
        }
    }

    private void startMessagePolling() {
        if (messageRefreshTimer != null) {
            messageRefreshTimer.cancel();
        }
        messageRefreshTimer = new Timer(true);
        messageRefreshTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> {
                    if (currentUser != null && selectedChatPartner != null) {
                        List<ChatMessage> latestMessages = chatService.fetchMessagesBetweenUsers(currentUser.getId(),
                                selectedChatPartner.getId());
                        if (latestMessages != null) {
                            if (!areMessageListsSemanticallyIdentical(observableChatMessages, latestMessages)) {
                                observableChatMessages.setAll(latestMessages);
                            }
                        }
                    }
                });
            }
        }, 0, 3000);
    }

    private boolean areMessageListsSemanticallyIdentical(List<ChatMessage> list1, List<ChatMessage> list2) {
        if (list1.size() != list2.size())
            return false;
        for (int i = 0; i < list1.size(); i++) {
            ChatMessage msg1 = list1.get(i);
            ChatMessage msg2 = list2.get(i);
            if (msg1.getId() != msg2.getId() ||
                    !msg1.getMessage().equals(msg2.getMessage())) {
                return false;
            }
        }
        return true;
    }

    private void scrollToBottom() {
        if (!observableChatMessages.isEmpty()) {
            chatMessagesListView.scrollTo(observableChatMessages.size() - 1);
        }
    }

    public void shutdown() {
        if (messageRefreshTimer != null) {
            messageRefreshTimer.cancel();
        }
    }

    // Modern user contact cell with avatar and status
    private class UserContactCell extends ListCell<User> {
        private final HBox cellContainer = new HBox(10);
        private final Circle avatar = new Circle(20);
        private final VBox userInfo = new VBox(3);
        private final Label nameLabel = new Label();
        private final Label previewLabel = new Label();
        private final Circle statusIndicator = new Circle(5);

        public UserContactCell() {
            avatar.setFill(Color.LIGHTGRAY);

            nameLabel.getStyleClass().add("chat-contact-name");
            previewLabel.getStyleClass().add("chat-contact-preview");

            userInfo.getChildren().addAll(nameLabel, previewLabel);
            HBox.setHgrow(userInfo, Priority.ALWAYS);

            statusIndicator.getStyleClass().add("chat-status-indicator");

            cellContainer.setAlignment(Pos.CENTER_LEFT);
            cellContainer.getChildren().addAll(avatar, userInfo, statusIndicator);
            cellContainer.setPadding(new Insets(5, 10, 5, 10));
        }

        @Override
        protected void updateItem(User user, boolean empty) {
            super.updateItem(user, empty);

            if (empty || user == null || user.getNom() == null) {
                setText(null);
                setGraphic(null);
            } else {
                nameLabel.setText(user.getNom());
                previewLabel.setText("Tap to start chatting");

                // Randomly set status indicator for demo purposes
                boolean isOnline = Math.random() > 0.3;
                if (isOnline) {
                    statusIndicator.getStyleClass().remove("offline");
                } else {
                    if (!statusIndicator.getStyleClass().contains("offline")) {
                        statusIndicator.getStyleClass().add("offline");
                    }
                }

                setGraphic(cellContainer);
            }
        }
    }

    // Modern chat message cell with bubbles - fixed for horizontal text display
    private class ModernChatMessageCell extends ListCell<ChatMessage> {
        private final HBox messageContainer = new HBox(10);
        private final VBox messageBox = new VBox(3);
        private final TextFlow messageTextFlow = new TextFlow();
        private final Label timeLabel = new Label();
        private final User cellCurrentUser;

        public ModernChatMessageCell(User currentUser) {
            this.cellCurrentUser = currentUser;

            // Don't set preferred width here - will adjust based on message direction
            messageTextFlow.getStyleClass().add("message-bubble");

            // Important: Make sure text flows horizontally
            messageTextFlow.setMinWidth(150); // Minimum width to ensure horizontal flow

            timeLabel.getStyleClass().add("message-time");
            messageBox.getChildren().addAll(messageTextFlow, timeLabel);
            messageContainer.setPadding(new Insets(2, 8, 2, 8));
        }

        @Override
        protected void updateItem(ChatMessage message, boolean empty) {
            super.updateItem(message, empty);

            if (empty || message == null || cellCurrentUser == null) {
                setText(null);
                setGraphic(null);
            } else {
                messageContainer.getChildren().clear();
                messageTextFlow.getChildren().clear();

                // Create the text element properly for horizontal display
                Text messageText = new Text(message.getMessage());
                // Don't set wrapping width here - let the TextFlow handle wrapping naturally
                messageTextFlow.getChildren().add(messageText);

                // Format time
                LocalDateTime messageTime = message.getCreatedAt();
                timeLabel.setText(messageTime != null ? messageTime.format(DateTimeFormatter.ofPattern("h:mm a")) : "");

                double containerWidth = getListView().getWidth() * 0.9; // Get current list width for scaling

                boolean isCurrentUserMessage = message.getSender() != null &&
                        message.getSender().getId() == cellCurrentUser.getId();

                if (isCurrentUserMessage) {
                    // Sent messages - right aligned
                    messageContainer.setAlignment(Pos.CENTER_RIGHT);
                    messageBox.setAlignment(Pos.CENTER_RIGHT);
                    timeLabel.setAlignment(Pos.CENTER_RIGHT);
                    messageTextFlow.getStyleClass().remove("received");
                    messageTextFlow.getStyleClass().add("sent");

                    // Set maximum width for sent messages (slightly narrower)
                    double maxWidth = Math.min(containerWidth * 0.6, 350);
                    messageTextFlow.setMaxWidth(maxWidth);

                    messageContainer.getChildren().add(messageBox);
                } else {
                    // Received messages - left aligned with avatar
                    messageContainer.setAlignment(Pos.CENTER_LEFT);
                    messageBox.setAlignment(Pos.CENTER_LEFT);
                    timeLabel.setAlignment(Pos.CENTER_LEFT);
                    messageTextFlow.getStyleClass().remove("sent");
                    messageTextFlow.getStyleClass().add("received");

                    // Set maximum width for received messages (slightly wider)
                    double maxWidth = Math.min(containerWidth * 0.7, 400);
                    messageTextFlow.setMaxWidth(maxWidth);

                    // Add avatar for received messages
                    Circle avatar = new Circle(14);
                    avatar.setFill(Color.LIGHTGRAY);
                    HBox.setMargin(avatar, new Insets(0, 5, 0, 0));
                    messageContainer.getChildren().addAll(avatar, messageBox);
                }

                setGraphic(messageContainer);
            }
        }
    }
}
