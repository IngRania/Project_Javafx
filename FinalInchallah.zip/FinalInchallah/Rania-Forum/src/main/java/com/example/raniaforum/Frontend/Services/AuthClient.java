package com.example.raniaforum.Frontend.Services;

import com.example.raniaforum.Backend.Models.User;

public class AuthClient {
    public User login(String nom, String pass) {
        // Appel HTTP pour authentifier l'utilisateur
        return null;
    }
}