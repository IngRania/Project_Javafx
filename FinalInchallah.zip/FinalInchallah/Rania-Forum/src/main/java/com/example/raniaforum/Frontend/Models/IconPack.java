package com.example.raniaforum.Frontend.Models;

import javafx.scene.Node;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

/**
 * Utility class for loading and creating FontAwesome icons in JavaFX.
 * This class provides methods to easily integrate FontAwesome icons into a
 * JavaFX application.
 */
public class IconPack {

    // Font paths
    private static final String FONT_AWESOME_SOLID = "/fonts/fa-solid-900.ttf";
    private static final String FONT_AWESOME_REGULAR = "/fonts/fa-regular-400.ttf";
    private static final String FONT_AWESOME_BRANDS = "/fonts/fa-brands-400.ttf";

    // Pre-loaded fonts
    private static Font fontSolid;
    private static Font fontRegular;
    private static Font fontBrands;

    // Common icon sizes
    public static final int SIZE_SMALL = 14;
    public static final int SIZE_MEDIUM = 18;
    public static final int SIZE_LARGE = 24;
    public static final int SIZE_EXTRA_LARGE = 32;

    // Common icons used in the application
    public static final String ICON_DASHBOARD = "\uf3fd"; // Chart pie
    public static final String ICON_CATEGORY = "\uf07b"; // Folder
    public static final String ICON_FORUM = "\uf086"; // Comments
    public static final String ICON_USER = "\uf007"; // User
    public static final String ICON_CHAT = "\uf4ad"; // Comment dots
    public static final String ICON_SETTINGS = "\uf013"; // Gear/Cog
    public static final String ICON_LOGOUT = "\uf2f5"; // Sign out
    public static final String ICON_ADD = "\uf067"; // Plus
    public static final String ICON_EDIT = "\uf044"; // Pen
    public static final String ICON_DELETE = "\uf1f8"; // Trash
    public static final String ICON_SEARCH = "\uf002"; // Search
    public static final String ICON_REFRESH = "\uf021"; // Sync
    public static final String ICON_HOME = "\uf015"; // Home
    public static final String ICON_SAVE = "\uf0c7"; // Save
    public static final String ICON_CANCEL = "\uf00d"; // Times/Close
    public static final String ICON_SEND = "\uf1d8"; // Paper plane
    public static final String ICON_IMAGE = "\uf03e"; // Image

    /**
     * Initializes the FontAwesome fonts.
     * This method should be called once at application startup.
     */
    public static void initialize() {
        try {
            fontSolid = Font.loadFont(
                    IconPack.class.getResourceAsStream(FONT_AWESOME_SOLID), 12);
            fontRegular = Font.loadFont(
                    IconPack.class.getResourceAsStream(FONT_AWESOME_REGULAR), 12);
            fontBrands = Font.loadFont(
                    IconPack.class.getResourceAsStream(FONT_AWESOME_BRANDS), 12);

            if (fontSolid == null || fontRegular == null || fontBrands == null) {
                System.err.println("Failed to load FontAwesome fonts!");
            }
        } catch (Exception e) {
            System.err.println("Error loading FontAwesome fonts: " + e.getMessage());
        }
    }

    /**
     * Creates a solid FontAwesome icon.
     *
     * @param iconCode The Unicode character representing the icon
     * @param size     The size of the icon
     * @param color    The color of the icon
     * @return A Text node containing the icon
     */
    public static Node createSolidIcon(String iconCode, int size, Color color) {
        ensureFontsLoaded();
        Text icon = new Text(iconCode);
        icon.setFont(Font.font(fontSolid.getFamily(), size));
        icon.setFill(color);
        return icon;
    }

    /**
     * Creates a regular FontAwesome icon.
     *
     * @param iconCode The Unicode character representing the icon
     * @param size     The size of the icon
     * @param color    The color of the icon
     * @return A Text node containing the icon
     */
    public static Node createRegularIcon(String iconCode, int size, Color color) {
        ensureFontsLoaded();
        Text icon = new Text(iconCode);
        icon.setFont(Font.font(fontRegular.getFamily(), size));
        icon.setFill(color);
        return icon;
    }

    /**
     * Creates a brands FontAwesome icon.
     *
     * @param iconCode The Unicode character representing the icon
     * @param size     The size of the icon
     * @param color    The color of the icon
     * @return A Text node containing the icon
     */
    public static Node createBrandIcon(String iconCode, int size, Color color) {
        ensureFontsLoaded();
        Text icon = new Text(iconCode);
        icon.setFont(Font.font(fontBrands.getFamily(), size));
        icon.setFill(color);
        return icon;
    }

    /**
     * Creates a solid icon with default medium size and primary color.
     * 
     * @param iconCode The Unicode character representing the icon
     * @return A Text node containing the icon
     */
    public static Node createIcon(String iconCode) {
        return createSolidIcon(iconCode, SIZE_MEDIUM, Color.valueOf("#2088ee"));
    }

    /**
     * Ensures that the fonts are loaded before creating icons.
     */
    private static void ensureFontsLoaded() {
        if (fontSolid == null || fontRegular == null || fontBrands == null) {
            initialize();
        }
    }
}
