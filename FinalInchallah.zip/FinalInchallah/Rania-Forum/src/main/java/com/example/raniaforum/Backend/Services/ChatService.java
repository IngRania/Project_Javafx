package com.example.raniaforum.Backend.Services;

import com.example.DatabaseConnection;
import com.example.raniaforum.Backend.Models.ChatMessage;
import com.example.raniaforum.Backend.Models.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ChatService {

    public ChatMessage sendMessage(ChatMessage chatMessage) {
        // Table `chat_message` columns: id, sender_id, receiver_id, message, created_at
        // Removed `read` column as it's not in the provided schema
        String query = "INSERT INTO chat_message (sender_id, receiver_id, message, created_at) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS)) {

            if (chatMessage.getSender() == null || chatMessage.getReceiver() == null) {
                System.err.println("Sender or Receiver cannot be null in ChatMessage.");
                return null;
            }
            stmt.setInt(1, chatMessage.getSender().getId());
            stmt.setInt(2, chatMessage.getReceiver().getId());
            stmt.setString(3, chatMessage.getMessage());
            stmt.setTimestamp(4, Timestamp.valueOf(chatMessage.getCreatedAt()));
            // Removed setting read status: stmt.setBoolean(5, chatMessage.isRead());

            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        chatMessage.setId(rs.getInt(1));
                        return chatMessage;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Consider more robust error handling
        }
        return null;
    }

    public List<ChatMessage> fetchMessagesBetweenUsers(int userId1, int userId2) {
        List<ChatMessage> messages = new ArrayList<>();
        // Removed `cm.read` from SELECT as it's not in the schema
        String query = "SELECT cm.id, cm.message, cm.created_at, " +
                "s.id as sender_id, s.nom as sender_nom, " +
                "r.id as receiver_id, r.nom as receiver_nom " +
                "FROM chat_message cm " +
                "JOIN user s ON cm.sender_id = s.id " +
                "JOIN user r ON cm.receiver_id = r.id " +
                "WHERE (cm.sender_id = ? AND cm.receiver_id = ?) OR (cm.sender_id = ? AND cm.receiver_id = ?) " +
                "ORDER BY cm.created_at ASC";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId1);
            stmt.setInt(2, userId2);
            stmt.setInt(3, userId2);
            stmt.setInt(4, userId1);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                ChatMessage msg = new ChatMessage();
                msg.setId(rs.getInt("id"));
                msg.setMessage(rs.getString("message"));
                Timestamp ts = rs.getTimestamp("created_at");
                if (ts != null) {
                    msg.setCreatedAt(ts.toLocalDateTime());
                }
                // Removed: msg.setRead(rs.getBoolean("read"));

                User sender = new User();
                sender.setId(rs.getInt("sender_id"));
                sender.setNom(rs.getString("sender_nom"));
                msg.setSender(sender);

                User receiver = new User();
                receiver.setId(rs.getInt("receiver_id"));
                receiver.setNom(rs.getString("receiver_nom"));
                msg.setReceiver(receiver);

                messages.add(msg);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Consider more robust error handling
        }
        return messages;
    }

    // The concept of unread messages based on a `read` flag is removed
    // as the `read` column is not in the database schema.
    // If you need to fetch all messages for a user, you can adapt
    // fetchMessagesBetweenUsers
    // or create a new method like fetchAllMessagesForUser(int userId).
    public List<ChatMessage> fetchUnreadMessages(int userId) {
        // This method is now problematic as there's no `read` column.
        // Returning an empty list or removing/repurposing this method might be
        // necessary.
        System.out.println(
                "Warning: fetchUnreadMessages called, but no 'read' status in DB schema. Returning empty list.");
        return new ArrayList<>();
    }

    // The markMessageAsRead method is removed as there is no `read` column in the
    // schema.
    // public void markMessageAsRead(int messageId) { ... }
}