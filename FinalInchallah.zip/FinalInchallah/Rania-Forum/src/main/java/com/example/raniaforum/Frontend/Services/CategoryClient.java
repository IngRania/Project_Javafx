package com.example.raniaforum.Frontend.Services;

import com.example.raniaforum.Backend.Models.Category;
import java.util.List;

public class CategoryClient {
    public List<Category> getAllCategories() {
        // Appel HTTP pour récupérer toutes les catégories
        return null;
    }

    public Category addCategory(Category c) {
        // Appel HTTP pour ajouter une catégorie
        return null;
    }

    public Category updateCategory(Category c) {
        // Appel HTTP pour mettre à jour une catégorie
        return null;
    }

    public void deleteCategory(int id) {
        // Appel HTTP pour supprimer une catégorie
    }

    public List<Category> searchCategories(String keyword) {
        // Appel HTTP pour rechercher des catégories par nom
        return null;
    }

    public List<Category> sortCategoriesByDate(boolean ascending) {
        // Appel HTTP pour trier les catégories par date
        return null;
    }
}