package com.example.raniaforum.Frontend.Controllers;

import com.example.raniaforum.Backend.Models.Forum;
import com.example.raniaforum.Backend.Services.ForumService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;

import java.util.List;

public class ForumViewController {

    @FXML
    private VBox forumPostsContainer; // Renamed from mainForumViewContainer for clarity

    @FXML
    private ListView<Forum> forumListView;

    @FXML
    private Label noPostsLabel;

    private ForumService forumService;
    private ObservableList<Forum> observableForumList;

    public void initialize() {
        forumService = new ForumService();
        observableForumList = FXCollections.observableArrayList();
        forumListView.setItems(observableForumList);

        // Custom cell factory to display forum details
        forumListView.setCellFactory(param -> new ForumListCell());

        loadForumPosts();
    }

    private void loadForumPosts() {
        List<Forum> forums = forumService.findAll();
        if (forums != null && !forums.isEmpty()) {
            observableForumList.setAll(forums);
            forumListView.setVisible(true);
            noPostsLabel.setVisible(false);
        } else {
            forumListView.setVisible(false);
            noPostsLabel.setVisible(true);
            noPostsLabel.setText("No forum posts available yet.");
        }
    }

    // Custom ListCell for displaying Forum objects
    // This would typically be a more complex cell, perhaps defined in its own FXML
    private static class ForumListCell extends javafx.scene.control.ListCell<Forum> {
        @Override
        protected void updateItem(Forum forum, boolean empty) {
            super.updateItem(forum, empty);
            if (empty || forum == null) {
                setText(null);
                setGraphic(null);
            } else {
                // Simple display: Title and Content
                // For a richer display, you might use an HBox or VBox with multiple Labels,
                // etc.
                VBox displayBox = new VBox(5);
                Label titleLabel = new Label(forum.getTitle()); // Changed from getTitre
                titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 1.2em;");
                Label contentPreviewLabel = new Label(forum.getContent()); // Changed from getContenu
                contentPreviewLabel.setWrapText(true);
                contentPreviewLabel.setMaxHeight(60); // Preview of content
                Label authorLabel = new Label(
                        "By: " + (forum.getUser() != null ? forum.getUser().getNom() : "Unknown User")); // Changed from
                                                                                                         // getUtilisateur
                authorLabel.setStyle("-fx-font-style: italic; -fx-font-size: 0.9em;");

                displayBox.getChildren().addAll(titleLabel, contentPreviewLabel, authorLabel);
                setGraphic(displayBox);
            }
        }
    }
}
