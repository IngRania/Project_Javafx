package com.example.raniaforum.Frontend.Services;

import com.example.raniaforum.Backend.Models.ChatMessage;

public class ChatClient {
    public void connectWebSocket(int userId) {
        // Connexion WebSocket pour l'utilisateur
    }

    public ChatMessage send(int toUserId, String message) {
        // Appel WebSocket pour envoyer un message
        return null;
    }

    public void onMessageReceived(Listener callback) {
        // Configuration du callback pour les messages reçus
    }

    public interface Listener {
        void handle(ChatMessage message);
    }
}