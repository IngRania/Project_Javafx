package com.example.raniaforum.Frontend.Controllers;

import com.example.raniaforum.Backend.Models.Category;
import com.example.raniaforum.Backend.Services.CategoryService;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class EditCategoryController {

    @FXML
    private TextField categoryNameField;

    @FXML
    private TextArea descriptionField;

    @FXML
    private Label nameErrorLabel;

    @FXML
    private Label descriptionErrorLabel;

    private CategoryService categoryService;
    private Category currentCategory;

    public void initialize() {
        categoryService = new CategoryService();
    }

    public void setCategory(Category category) {
        this.currentCategory = category;

        categoryNameField.setText(category.getName());
        descriptionField.setText(category.getDescription());
    }

    @FXML
    private void handleSave() {
        clearErrors();

        if (validateInputs()) {
            currentCategory.setName(categoryNameField.getText().trim());
            currentCategory.setDescription(descriptionField.getText().trim());

            try {
                categoryService.update(currentCategory); // Corrected method name to 'update'
                closeWindow();
                // Show success notification
            } catch (Exception e) {
                // Handle error
                showError("Failed to update category: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleCancel() {
        closeWindow();
    }

    private boolean validateInputs() {
        boolean isValid = true;

        if (categoryNameField.getText().trim().isEmpty()) {
            nameErrorLabel.setText("Category name is required");
            nameErrorLabel.setVisible(true);
            isValid = false;
        }

        if (descriptionField.getText().trim().isEmpty()) {
            descriptionErrorLabel.setText("Description is required");
            descriptionErrorLabel.setVisible(true);
            isValid = false;
        }

        return isValid;
    }

    private void clearErrors() {
        nameErrorLabel.setVisible(false);
        descriptionErrorLabel.setVisible(false);
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void closeWindow() {
        Stage stage = (Stage) categoryNameField.getScene().getWindow();
        stage.close();
    }
}
