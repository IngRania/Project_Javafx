package com.example.raniaforum.Frontend.Services;

import com.example.raniaforum.Backend.Models.Forum;
import java.util.List;

public class ForumClient {
    public List<Forum> getForumsByCategory(int catId) {
        // Appel HTTP pour récupérer les forums par catégorie
        return null;
    }

    public List<Forum> getAllForums() {
        // Appel HTTP pour récupérer tous les forums
        return null;
    }

    public Forum addForum(Forum f) {
        // Appel HTTP pour ajouter un forum
        return null;
    }

    public Forum updateForum(Forum f) {
        // Appel HTTP pour mettre à jour un forum
        return null;
    }

    public void deleteForum(int id) {
        // Appel HTTP pour supprimer un forum
    }

    public List<Forum> searchForums(String keyword) {
        // Appel HTTP pour rechercher des forums par titre
        return null;
    }

    public List<Forum> sortForumsByDate(boolean ascending) {
        // Appel HTTP pour trier les forums par date
        return null;
    }
}