package com.example.raniaforum.Frontend.Controllers;

import com.example.raniaforum.Backend.Models.Category;
import com.example.raniaforum.Backend.Models.Forum;
import com.example.raniaforum.Backend.Models.User; // Added import for User
import com.example.raniaforum.Backend.Services.CategoryService;
import com.example.raniaforum.Backend.Services.ForumService;
import com.example.raniaforum.Backend.Services.UserService;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

public class AddForumController {

    @FXML
    private TextField forumTitleField;

    @FXML
    private ComboBox<Category> categoryComboBox;

    @FXML
    private TextArea contentField;

    @FXML
    private Label titleErrorLabel;

    @FXML
    private Label categoryErrorLabel;

    @FXML
    private Label contentErrorLabel;

    @FXML
    private Button selectImageButton;

    @FXML
    private Label imagePathLabel;

    @FXML
    private ImageView forumImageView;

    @FXML
    private Label imageErrorLabel;

    private ForumService forumService;
    private CategoryService categoryService;
    private File selectedImageFile;
    private UserService userService; // For fetching the current user

    // Directory to store images
    private static final String IMAGE_STORAGE_DIR = System.getProperty("user.home") + File.separator + "forum_images";

    public void initialize() {
        forumService = new ForumService();
        categoryService = new CategoryService();
        userService = new UserService(); // Initialize UserService

        // Create image storage directory if it doesn't exist
        Path storagePath = Paths.get(IMAGE_STORAGE_DIR);
        if (!Files.exists(storagePath)) {
            try {
                Files.createDirectories(storagePath);
            } catch (IOException e) {
                e.printStackTrace();
                showError("Could not create image storage directory: " + e.getMessage());
                // Disable image selection if directory creation fails
                selectImageButton.setDisable(true);
            }
        }

        loadCategories();
        imagePathLabel.setManaged(false); // Hide when no text
        forumImageView.setManaged(false); // Hide when no image
    }

    private void loadCategories() {
        try {
            List<Category> categories = categoryService.findAll();
            categoryComboBox.setItems(FXCollections.observableArrayList(categories));

            categoryComboBox.setCellFactory(param -> new ListCell<Category>() {
                @Override
                protected void updateItem(Category item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setText(null);
                    } else {
                        setText(item.getName());
                    }
                }
            });

            categoryComboBox.setConverter(new javafx.util.StringConverter<Category>() {
                @Override
                public String toString(Category category) {
                    if (category == null) {
                        return null;
                    }
                    return category.getName();
                }

                @Override
                public Category fromString(String string) {
                    return null;
                }
            });
        } catch (Exception e) {
            showError("Error loading categories: " + e.getMessage());
        }
    }

    @FXML
    private void handleSelectImage() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Forum Image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif"));
        Stage stage = (Stage) selectImageButton.getScene().getWindow();
        selectedImageFile = fileChooser.showOpenDialog(stage);

        if (selectedImageFile != null) {
            try {
                Image image = new Image(selectedImageFile.toURI().toString());
                forumImageView.setImage(image);
                forumImageView.setManaged(true);
                forumImageView.setVisible(true);
                imagePathLabel.setText(selectedImageFile.getName());
                imagePathLabel.setManaged(true);
                imagePathLabel.setVisible(true);
                imageErrorLabel.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
                imageErrorLabel.setText("Failed to load image preview.");
                imageErrorLabel.setVisible(true);
                selectedImageFile = null; // Reset if loading failed
                forumImageView.setImage(null);
                forumImageView.setManaged(false);
                imagePathLabel.setText("");
                imagePathLabel.setManaged(false);
            }
        } else {
            // User cancelled file selection
            // forumImageView.setImage(null); // Keep existing image if they cancel
            // imagePathLabel.setText(""); // Keep existing path if they cancel
        }
    }

    @FXML
    private void handleSave() {
        clearErrors();

        if (validateInputs()) {
            Forum forum = new Forum();
            forum.setTitle(forumTitleField.getText().trim());
            forum.setContent(contentField.getText().trim());
            forum.setCategory(categoryComboBox.getValue());
            forum.setCreatedAt(LocalDateTime.now());

            // TODO: Get the actual logged-in user. For now, using a placeholder or fetching
            // user ID 1.
            // This needs to be replaced with actual session management.
            User currentUser = userService.findById(1); // Corrected method call
            if (currentUser == null) {
                showError("Could not identify current user. Please log in again.");
                return;
            }
            forum.setUser(currentUser);

            if (selectedImageFile != null) {
                try {
                    String originalFileName = selectedImageFile.getName();
                    String fileExtension = "";
                    int dotIndex = originalFileName.lastIndexOf('.');
                    if (dotIndex > 0 && dotIndex < originalFileName.length() - 1) {
                        fileExtension = originalFileName.substring(dotIndex);
                    }
                    String newFileName = UUID.randomUUID().toString() + fileExtension;
                    Path destinationPath = Paths.get(IMAGE_STORAGE_DIR, newFileName);
                    Files.copy(selectedImageFile.toPath(), destinationPath, StandardCopyOption.REPLACE_EXISTING);
                    forum.setImageUrl(newFileName); // Store only the filename
                } catch (IOException e) {
                    e.printStackTrace();
                    showError("Failed to save image: " + e.getMessage());
                    imageErrorLabel.setText("Error saving image.");
                    imageErrorLabel.setVisible(true);
                    return; // Don't proceed with forum creation if image saving fails
                }
            } else {
                forum.setImageUrl(null); // No image selected
            }

            try {
                forumService.create(forum);
                closeWindow();
                // Optionally, trigger a refresh in the calling view (DashboardAdminController)
            } catch (Exception e) {
                e.printStackTrace();
                showError("Failed to create forum: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleCancel() {
        closeWindow();
    }

    private boolean validateInputs() {
        boolean isValid = true;

        if (forumTitleField.getText().trim().isEmpty()) {
            titleErrorLabel.setText("Forum title is required");
            titleErrorLabel.setVisible(true);
            isValid = false;
        }

        if (categoryComboBox.getValue() == null) {
            categoryErrorLabel.setText("Please select a category");
            categoryErrorLabel.setVisible(true);
            isValid = false;
        }

        if (contentField.getText().trim().isEmpty()) {
            contentErrorLabel.setText("Description is required");
            contentErrorLabel.setVisible(true);
            isValid = false;
        }

        return isValid;
    }

    private void clearErrors() {
        titleErrorLabel.setVisible(false);
        categoryErrorLabel.setVisible(false);
        contentErrorLabel.setVisible(false);
        imageErrorLabel.setVisible(false); // Clear image error
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void closeWindow() {
        Stage stage = (Stage) forumTitleField.getScene().getWindow();
        stage.close();
    }
}
