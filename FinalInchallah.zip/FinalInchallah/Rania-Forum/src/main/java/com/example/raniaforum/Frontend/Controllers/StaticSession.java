
package com.example.raniaforum.Frontend.Controllers;

import com.example.raniaforum.Backend.Models.User;

public class StaticSession {
    private static User currentUser;

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void setCurrentUser(User user) {
        currentUser = user;
    }

    public static void clearSession() {
        currentUser = null;
    }
}
