package com.example.raniaforum.Frontend.Controllers;

import com.example.raniaforum.Backend.Models.Category;
import com.example.raniaforum.Backend.Models.Forum;
import com.example.raniaforum.Backend.Services.CategoryService;
import com.example.raniaforum.Backend.Services.ForumService;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.nio.file.Paths;
import java.util.List;

public class EditForumController {

    @FXML
    private TextField forumTitleField;

    @FXML
    private ComboBox<Category> categoryComboBox;

    @FXML
    private TextArea contentField;

    @FXML
    private ImageView forumImageView;

    @FXML
    private Label titleErrorLabel;

    @FXML
    private Label categoryErrorLabel;

    @FXML
    private Label contentErrorLabel;

    @FXML
    private Label imageErrorLabel;

    private File selectedImageFile;
    private ForumService forumService;
    private CategoryService categoryService;
    private Forum currentForum;

    public void initialize() {
        forumService = new ForumService();
        categoryService = new CategoryService();
        loadCategories();
    }

    public void setForum(Forum forum) {
        this.currentForum = forum;
        populateForumData();
    }

    private void populateForumData() {
        if (currentForum != null) {
            forumTitleField.setText(currentForum.getTitle());
            contentField.setText(currentForum.getContent());

            if (currentForum.getCategory() != null) {
                categoryComboBox.setValue(currentForum.getCategory());
            }

            if (currentForum.getImageUrl() != null && !currentForum.getImageUrl().isEmpty()) {
                try {
                    File imageFile = new File(currentForum.getImageUrl());
                    if (imageFile.exists()) {
                        Image image = new Image(imageFile.toURI().toString());
                        forumImageView.setImage(image);
                        selectedImageFile = imageFile;
                    } else {
                        // Fallback if the path is not absolute or file moved
                        try {
                            Image image = new Image(getClass().getResourceAsStream(currentForum.getImageUrl()));
                            if (image != null && !image.isError()) {
                                forumImageView.setImage(image);
                            } else {
                                setDefaultImage();
                            }
                        } catch (Exception e) {
                            setDefaultImage();
                        }
                    }
                } catch (Exception e) {
                    setDefaultImage();
                    imageErrorLabel.setText("Error loading image.");
                    imageErrorLabel.setVisible(true);
                }
            } else {
                setDefaultImage();
            }
        }
    }

    private void setDefaultImage() {
        try {
            Image placeholder = new Image(getClass().getResourceAsStream("/images/forum_placeholder.png"));
            forumImageView.setImage(placeholder);
        } catch (Exception e) {
            // Handle error if placeholder is not found
            System.err.println("Placeholder image not found: " + e.getMessage());
        }
    }

    private void loadCategories() {
        try {
            List<Category> categories = categoryService.findAll();
            categoryComboBox.setItems(FXCollections.observableArrayList(categories));

            categoryComboBox.setCellFactory(param -> new ListCell<Category>() {
                @Override
                protected void updateItem(Category item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null || item.getName() == null) {
                        setText(null);
                    } else {
                        setText(item.getName());
                    }
                }
            });

            categoryComboBox.setConverter(new javafx.util.StringConverter<Category>() {
                @Override
                public String toString(Category category) {
                    return category == null || category.getName() == null ? null : category.getName();
                }

                @Override
                public Category fromString(String string) {
                    return categoryComboBox.getItems().stream().filter(c -> c.getName().equals(string)).findFirst()
                            .orElse(null);
                }
            });

        } catch (Exception e) {
            showError("Error loading categories: " + e.getMessage());
        }
    }

    @FXML
    private void handleBrowseImage() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Forum Cover Image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif"));
        File projectDir = Paths.get(System.getProperty("user.dir"), "src", "main", "resources", "images").toFile();
        if (projectDir.exists() && projectDir.isDirectory()) {
            fileChooser.setInitialDirectory(projectDir);
        }

        selectedImageFile = fileChooser.showOpenDialog(forumTitleField.getScene().getWindow());

        if (selectedImageFile != null) {
            try {
                Image image = new Image(selectedImageFile.toURI().toString());
                forumImageView.setImage(image);
                imageErrorLabel.setVisible(false);
            } catch (Exception e) {
                imageErrorLabel.setText("Failed to load image.");
                imageErrorLabel.setVisible(true);
            }
        }
    }

    @FXML
    private void handleSave() {
        clearErrors();
        if (validateInputs() && currentForum != null) {
            currentForum.setTitle(forumTitleField.getText().trim());
            currentForum.setContent(contentField.getText().trim());
            currentForum.setCategory(categoryComboBox.getValue());

            if (selectedImageFile != null) {
                currentForum.setImageUrl(selectedImageFile.getPath());
            } else {
                // If no new image is selected, and there was no old image, or user wants to
                // remove image
                // currentForum.setImageUrl(null); // Or keep the old one if that's the desired
                // behavior
            }

            try {
                forumService.update(currentForum);
                closeWindow();
            } catch (Exception e) {
                showError("Failed to update forum: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleCancel() {
        closeWindow();
    }

    private boolean validateInputs() {
        boolean isValid = true;
        if (forumTitleField.getText() == null || forumTitleField.getText().trim().isEmpty()) {
            titleErrorLabel.setText("Title is required.");
            titleErrorLabel.setVisible(true);
            isValid = false;
        }
        if (categoryComboBox.getValue() == null) {
            categoryErrorLabel.setText("Category is required.");
            categoryErrorLabel.setVisible(true);
            isValid = false;
        }
        if (contentField.getText() == null || contentField.getText().trim().isEmpty()) {
            contentErrorLabel.setText("Content is required.");
            contentErrorLabel.setVisible(true);
            isValid = false;
        }
        return isValid;
    }

    private void clearErrors() {
        titleErrorLabel.setVisible(false);
        categoryErrorLabel.setVisible(false);
        contentErrorLabel.setVisible(false);
        imageErrorLabel.setVisible(false);
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void closeWindow() {
        Stage stage = (Stage) forumTitleField.getScene().getWindow();
        stage.close();
    }
}
