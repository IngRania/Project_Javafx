package com.example.raniaforum.Backend.Services;

import com.example.DatabaseConnection;
import com.example.raniaforum.Backend.Models.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
// Consider adding a password hashing library if not already in use
// import org.mindrot.jbcrypt.BCrypt; // Example: jBCrypt

public class UserService {

    public User authenticate(String nom, String passwordPlain) {
        String query = "SELECT * FROM user WHERE nom = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nom);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String storedPassword = rs.getString("password");
                // Directly compare plain text passwords.
                // IMPORTANT: In a real application, store hashed passwords and compare hashes.
                // Example with jBCrypt: if (BCrypt.checkpw(passwordPlain, storedPassword)) {
                if (passwordPlain.equals(storedPassword)) {
                    User user = new User(rs.getInt("id"));
                    user.setNom(rs.getString("nom"));
                    user.setPasswordHash(storedPassword); // Assuming User model has setPasswordHash for the password
                                                          // field
                    user.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
                    return user;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle exceptions appropriately
        }
        return null;
    }

    public User findById(int id) {
        String query = "SELECT * FROM user WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                User user = new User(rs.getInt("id"));
                user.setNom(rs.getString("nom"));
                // Password field should ideally not be loaded here for general findById,
                // but if needed for some contexts, ensure it's handled securely.
                // user.setPasswordHash(rs.getString("password"));
                user.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
                return user;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public User create(User u) {
        // IMPORTANT: Hash the password before storing it.
        // String hashedPassword = BCrypt.hashpw(u.getPasswordHash(), BCrypt.gensalt());
        // // Example with jBCrypt
        String query = "INSERT INTO user (nom, password) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, u.getNom());
            stmt.setString(2, u.getPasswordHash()); // Store the plain password as per current model, or hashed password
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        u.setId(generatedKeys.getInt(1));
                        u.setCreatedAt(LocalDateTime.now()); // Set creation timestamp
                        return u;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void delete(int id) {
        String query = "DELETE FROM user WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Add other methods like update, getAllUsers etc. as needed
    public java.util.List<User> getAllUsersExceptCurrent(int currentUserId) {
        java.util.List<User> users = new java.util.ArrayList<>();
        String query = "SELECT id, nom, created_at FROM user WHERE id != ? ORDER BY nom ASC";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, currentUserId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                User user = new User(); // Uses the no-arg constructor
                user.setId(rs.getInt("id"));
                user.setNom(rs.getString("nom"));
                if (rs.getTimestamp("created_at") != null) {
                    user.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
                }
                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle exceptions appropriately
        }
        return users;
    }
}