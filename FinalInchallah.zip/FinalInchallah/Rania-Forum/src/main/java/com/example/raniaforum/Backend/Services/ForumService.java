package com.example.raniaforum.Backend.Services;

import com.example.DatabaseConnection;
import com.example.raniaforum.Backend.Models.Category;
import com.example.raniaforum.Backend.Models.Forum;
// User model import might still be needed if Forum model retains User field, but service won't populate it from forum table directly.
// import com.example.raniaforum.Backend.Models.User; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ForumService {

    public List<Forum> findAll() {
        List<Forum> forums = new ArrayList<>();
        // Removed JOIN with user table and user_nom
        String query = "SELECT f.*, c.name as category_name FROM forum f " +
                "JOIN category c ON f.category_id = c.id";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Forum f = new Forum();
                f.setId(rs.getInt("id"));
                f.setTitle(rs.getString("title"));
                f.setContent(rs.getString("content"));
                f.setImageUrl(rs.getString("image_url"));
                f.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());

                Category category = new Category();
                category.setId(rs.getInt("category_id"));
                category.setName(rs.getString("category_name"));
                f.setCategory(category);

                // Removed User population
                // User user = new User(rs.getInt("user_id"));
                // user.setNom(rs.getString("user_nom"));
                // f.setUser(user);

                forums.add(f);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return forums;
    }

    public List<Forum> findByCategory(int categoryId) {
        List<Forum> forums = new ArrayList<>();
        // Removed JOIN with user table and user_nom
        String query = "SELECT f.*, c.name as category_name FROM forum f " +
                "JOIN category c ON f.category_id = c.id WHERE f.category_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, categoryId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Forum f = new Forum();
                f.setId(rs.getInt("id"));
                f.setTitle(rs.getString("title"));
                f.setContent(rs.getString("content"));
                f.setImageUrl(rs.getString("image_url"));
                f.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());

                Category category = new Category();
                category.setId(rs.getInt("category_id"));
                category.setName(rs.getString("category_name"));
                f.setCategory(category);

                // Removed User population

                forums.add(f);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return forums;
    }

    public Forum findById(int id) {
        // Removed JOIN with user table and user_nom
        String query = "SELECT f.*, c.name as category_name FROM forum f " +
                "JOIN category c ON f.category_id = c.id WHERE f.id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Forum f = new Forum();
                f.setId(rs.getInt("id"));
                f.setTitle(rs.getString("title"));
                f.setContent(rs.getString("content"));
                f.setImageUrl(rs.getString("image_url"));
                f.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());

                Category category = new Category();
                category.setId(rs.getInt("category_id"));
                category.setName(rs.getString("category_name"));
                f.setCategory(category);

                // Removed User population

                return f;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Forum create(Forum f) {
        // Removed user_id from INSERT statement
        String query = "INSERT INTO forum (title, content, image_url, category_id, created_at) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, f.getTitle());
            stmt.setString(2, f.getContent());
            stmt.setString(3, f.getImageUrl());
            stmt.setInt(4, f.getCategory().getId());
            // Removed user_id parameter
            // if (f.getUser() != null && f.getUser().getId() > 0) {
            // stmt.setInt(5, f.getUser().getId());
            // } else {
            // stmt.setNull(5, java.sql.Types.INTEGER);
            // }
            stmt.setTimestamp(5, java.sql.Timestamp.valueOf(f.getCreatedAt())); // Parameter index adjusted

            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                f.setId(rs.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } catch (NullPointerException e) {
            e.printStackTrace();
            // Adjusted error message as user is no longer part of this context for creation
            System.err.println(
                    "Error creating forum: Null value encountered for category. Forum details: " + f.getTitle());
            return null;
        }
        return f;
    }

    public Forum update(Forum f) {
        // Removed user_id from UPDATE statement
        String query = "UPDATE forum SET title = ?, content = ?, image_url = ?, category_id = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, f.getTitle());
            stmt.setString(2, f.getContent());
            stmt.setString(3, f.getImageUrl());
            stmt.setInt(4, f.getCategory().getId());
            // Removed user_id parameter
            // if (f.getUser() != null && f.getUser().getId() > 0) {
            // stmt.setInt(5, f.getUser().getId());
            // } else {
            // stmt.setNull(5, java.sql.Types.INTEGER);
            // }
            stmt.setInt(5, f.getId()); // Parameter index adjusted
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } catch (NullPointerException e) {
            e.printStackTrace();
            // Adjusted error message
            System.err.println("Error updating forum: Null value encountered for category. Forum ID: " + f.getId());
            return null;
        }
        return f;
    }

    public void delete(int id) {
        // ...existing code...
        String query = "DELETE FROM forum WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Forum> searchByTitle(String keyword) {
        List<Forum> forums = new ArrayList<>();
        // Removed JOIN with user table and user_nom
        String query = "SELECT f.*, c.name as category_name FROM forum f " +
                "JOIN category c ON f.category_id = c.id WHERE f.title LIKE ?";
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, "%" + keyword + "%");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Forum f = new Forum();
                f.setId(rs.getInt("id"));
                f.setTitle(rs.getString("title"));
                f.setContent(rs.getString("content"));
                f.setImageUrl(rs.getString("image_url"));
                f.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());

                Category category = new Category();
                category.setId(rs.getInt("category_id"));
                category.setName(rs.getString("category_name"));
                f.setCategory(category);

                // Removed User population

                forums.add(f);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return forums;
    }

    public List<Forum> sortByDate(boolean asc) {
        List<Forum> forums = new ArrayList<>();
        // Removed JOIN with user table and user_nom
        String query = "SELECT f.*, c.name as category_name FROM forum f " +
                "JOIN category c ON f.category_id = c.id ORDER BY f.created_at " + (asc ? "ASC" : "DESC");
        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Forum f = new Forum();
                f.setId(rs.getInt("id"));
                f.setTitle(rs.getString("title"));
                f.setContent(rs.getString("content"));
                f.setImageUrl(rs.getString("image_url"));
                f.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());

                Category category = new Category();
                category.setId(rs.getInt("category_id"));
                category.setName(rs.getString("category_name"));
                f.setCategory(category);

                // Removed User population

                forums.add(f);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return forums;
    }
}