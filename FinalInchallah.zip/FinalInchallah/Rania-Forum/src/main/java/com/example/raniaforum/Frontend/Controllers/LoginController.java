package com.example.raniaforum.Frontend.Controllers;

import com.example.raniaforum.Backend.Models.User;
import com.example.raniaforum.Backend.Services.UserService;
import com.example.raniaforum.Frontend.Controllers.StaticSession; // Added import
import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label errorLabel;

    @FXML
    private Hyperlink forgotPasswordLink;

    @FXML
    private Hyperlink signupLink;

    private UserService userService;

    public void initialize() {
        userService = new UserService();
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showError("Please enter both username and password");
            return;
        }

        try {
            User user = userService.authenticate(username, password);

            if (user != null) {
                // Successful login, load the main application dashboard
                StaticSession.setCurrentUser(user); // Store user for chat or other features
                loadUserDashboard(); // Changed to load user dashboard
            } else {
                showError("Invalid username or password");
            }
        } catch (Exception e) {
            showError("Login error: " + e.getMessage());
        }
    }

    @FXML
    private void handleSignup() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/raniaforum/auth_signup.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root);
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Sign Up - Rania Forum");
        } catch (IOException e) {
            showError("Error loading signup form: " + e.getMessage());
        }
    }

    @FXML
    private void handleForgotPassword() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/raniaforum/auth_forgot_password.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root);
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Forgot Password - Rania Forum");
        } catch (IOException e) {
            showError("Error loading forgot password form: " + e.getMessage());
        }
    }

    private void loadUserDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/raniaforum/user_dashboard.fxml"));
            Parent root = loader.load();

            // Pass the user to the dashboard controller if needed
            // UserDashboardController controller = loader.getController();
            // controller.setCurrentUser(StaticSession.getCurrentUser());

            Scene scene = new Scene(root);
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Welcome - Rania Forum");
            stage.setMaximized(true);
        } catch (IOException e) {
            showError("Error loading user dashboard: " + e.getMessage());
            e.printStackTrace(); // For more detailed error logging during development
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);

        // Create fade transition for the error label
        FadeTransition fadeTransition = new FadeTransition(Duration.millis(3000), errorLabel);
        fadeTransition.setFromValue(1.0);
        fadeTransition.setToValue(0.0);
        fadeTransition.setDelay(Duration.millis(2000));
        fadeTransition.play();
    }
}
