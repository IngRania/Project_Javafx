package com.example.raniaforum.Frontend.Controllers;

import com.example.raniaforum.Backend.Models.Forum;
import com.example.raniaforum.Backend.Models.User;
// import com.example.raniaforum.Backend.Models.Comment; // Will be used later
import com.example.raniaforum.Backend.Services.ForumService;
// import com.example.raniaforum.Backend.Services.CommentService; // Will be used later
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.kordamp.ikonli.javafx.FontIcon;
import org.kordamp.ikonli.materialdesign2.MaterialDesignA;
import org.kordamp.ikonli.materialdesign2.MaterialDesignC;
import org.kordamp.ikonli.materialdesign2.MaterialDesignF;
import org.kordamp.ikonli.materialdesign2.MaterialDesignP; // Restored import
import org.kordamp.ikonli.materialdesign2.MaterialDesignS;
import org.kordamp.ikonli.materialdesign2.MaterialDesignT;
// import org.kordamp.ikonli.materialdesign2.MaterialDesignM; // Removed unused import
import org.kordamp.ikonli.materialdesign2.MaterialDesignE; // Removed unused import

import java.io.File;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
// import java.util.Optional; // Removed unused import

public class UserDashboardController {

    @FXML
    private BorderPane mainPane;
    @FXML
    private Label headerUsernameLabel;
    @FXML
    private Label navUsernameLabel;
    @FXML
    private VBox navigationBox;
    @FXML
    private HBox widgetsPane;
    @FXML
    private TextField forumSearchField;
    @FXML
    private ListView<Forum> forumListView;
    @FXML
    private ScrollPane forumScrollPane; // Added for better control if needed

    private User currentUser;
    private ForumService forumService;
    // private CommentService commentService; // Uncomment when CommentService is
    // ready

    private ObservableList<Forum> masterForumList = FXCollections.observableArrayList();
    private FilteredList<Forum> filteredForumList;

    private static final String IMAGE_STORAGE_DIR = System.getProperty("user.home") + File.separator + "forum_images";

    public void initialize() {
        currentUser = StaticSession.getCurrentUser();
        forumService = new ForumService();
        // commentService = new CommentService(); // Uncomment when CommentService is
        // ready

        if (currentUser != null) {
            String welcomeMessage = "Welcome, " + currentUser.getNom();
            headerUsernameLabel.setText(welcomeMessage);
            navUsernameLabel.setText(currentUser.getNom());
        } else {
            headerUsernameLabel.setText("Welcome, Guest");
            navUsernameLabel.setText("Guest");
            // Optionally disable features if no user is logged in
        }

        setupIconsForNavButtons();
        setupWidgets();

        // Temporarily comment out complex parts to debug potential loop/crash
        // System.out.println("DEBUG: setupForumListView() and loadForumsData() are
        // commented out.");
        setupForumListView();
        loadForumsData();

        // Temporarily comment out listener
        /*
         * if (forumSearchField != null) { // Ensure forumSearchField is initialized
         * forumSearchField.textProperty().addListener((observable, oldValue, newValue)
         * -> {
         * if (filteredForumList != null) {
         * filteredForumList.setPredicate(forum -> {
         * if (newValue == null || newValue.isEmpty()) {
         * return true;
         * }
         * String lowerCaseFilter = newValue.toLowerCase();
         * if (forum.getTitle() != null &&
         * forum.getTitle().toLowerCase().contains(lowerCaseFilter)) {
         * return true;
         * }
         * if (forum.getContent() != null &&
         * forum.getContent().toLowerCase().contains(lowerCaseFilter)) {
         * return true;
         * }
         * return forum.getCategory() != null && forum.getCategory().getName() != null
         * &&
         * forum.getCategory().getName().toLowerCase().contains(lowerCaseFilter);
         * });
         * }
         * });
         * }
         */
    }

    private void setupIconsForNavButtons() {
        // Assuming nav buttons have fx:id or can be looked up
        for (javafx.scene.Node node : navigationBox.getChildren()) {
            if (node instanceof Button) {
                Button button = (Button) node;
                switch (button.getText()) {
                    case "Home Feed":
                        button.setGraphic(new FontIcon(MaterialDesignA.ACCOUNT_GROUP_OUTLINE));
                        // Add click handler for Home Feed button
                        button.setOnAction(event -> handleNavigateForum());
                        break;
                    case "Messages":
                        button.setGraphic(new FontIcon(MaterialDesignC.CHAT_OUTLINE));
                        button.setOnAction(event -> handleNavigateChat());
                        break;
                    case "My Profile":
                        button.setGraphic(new FontIcon(MaterialDesignA.ACCOUNT_CIRCLE_OUTLINE));
                        button.setOnAction(event -> handleNavigateProfile());
                        break;
                    case "Settings":
                        button.setGraphic(new FontIcon(MaterialDesignC.COG)); // Changed to MaterialDesignC.COG
                        button.setOnAction(event -> handleNavigateSettings());
                        break;
                }
            }
        }
    }

    private void setupWidgets() {
        widgetsPane.getChildren().clear(); // Clear any placeholders

        // Example Widgets - reduce to one for debugging size issues
        WidgetCard totalForumsWidget = new WidgetCard("Total Forums", "0", "All active discussions",
                new FontIcon(MaterialDesignF.FORUM_OUTLINE));
        WidgetCard myPostsWidget = new WidgetCard("My Posts", "0", "Your contributions",
                new FontIcon(MaterialDesignP.POST_OUTLINE)); // Restored widget
        WidgetCard popularCategoriesWidget = new WidgetCard("Hot Category", "N/A", "Most active category",
                new FontIcon(MaterialDesignA.APPS)); // Restored widget

        // Fetch actual data
        if (forumService != null) {
            totalForumsWidget.setValue(String.valueOf(forumService.findAll().size()));

        }

        // widgetsPane.getChildren().addAll(totalForumsWidget); // Only add one widget
        // for now
        widgetsPane.getChildren().addAll(totalForumsWidget, myPostsWidget, popularCategoriesWidget); // Restored all
                                                                                                     // widgets
    }

    private void setupForumListView() {
        filteredForumList = new FilteredList<>(masterForumList, p -> true);
        forumListView.setItems(filteredForumList);
        forumListView.setCellFactory(param -> new ForumCardCell());
        // Ensure the ListView takes up the available height within the ScrollPane
        forumListView.prefHeightProperty().bind(forumScrollPane.heightProperty());
    }

    private void loadForumsData() {
        try {
            List<com.example.raniaforum.Backend.Models.Forum> forums = forumService.findAll(); // Original call,
                                                                                               // uncommented
            masterForumList.setAll(forums); // Populate with real data

            if (!masterForumList.isEmpty()) {
                System.out.println(
                        "DEBUG: Loaded " + masterForumList.size() + " forums from service into masterForumList.");
                if (!forumListView.getItems().isEmpty()) {
                    System.out.println("DEBUG: forumListView has items after setting masterForumList with real data.");
                } else {
                    System.out.println(
                            "DEBUG: forumListView is EMPTY after setting masterForumList with real data. This is unexpected if masterForumList is not empty.");
                }
            } else {
                System.out.println("DEBUG: No forums loaded from service. masterForumList is empty.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            showError("Failed to load forums: " + e.getMessage());
        }
    }

    @FXML
    private void handleRefreshForums() {
        loadForumsData();
    }

    @FXML
    private void handleNavigateForum() {
        try {
            // Ensure the main pane shows the forum content
            Parent forumView = FXMLLoader.load(
                    Objects.requireNonNull(getClass().getResource("/com/example/raniaforum/user_dashboard.fxml")));

            // If this view is already displayed, just refresh the data
            if (mainPane.getScene().getRoot() == forumView) {
                loadForumsData();
                return;
            }

            // Set forum content as the center of the main BorderPane
            BorderPane mainBorderPane = null;

            // Get the forum content from the loaded view
            if (forumView instanceof BorderPane) {
                mainBorderPane = (BorderPane) forumView;
                // Extract the forum list content
                Node centerContent = mainBorderPane.getCenter();

                // Update the main pane with the forum content
                mainPane.setCenter(centerContent);
            } else {
                // If just refreshing the current view
                loadForumsData();
            }

            System.out.println("Home Feed content loaded");
        } catch (IOException e) {
            e.printStackTrace();
            showError("Failed to load forum view: " + e.getMessage());
        }
    }

    @FXML
    private void handleNavigateChat() {
        try {
            Parent chatViewRoot = FXMLLoader
                    .load(Objects.requireNonNull(getClass().getResource("/com/example/raniaforum/chat_view.fxml")));
            // If UserDashboard is the main stage, switch its center content
            if (mainPane.getScene().getRoot() instanceof BorderPane) {
                ((BorderPane) mainPane.getScene().getRoot()).setCenter(chatViewRoot);
            } else { // Fallback: open in new stage or handle differently
                Stage stage = new Stage();
                stage.setTitle("Chat");
                stage.setScene(new Scene(chatViewRoot));
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.show();
            }
        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
            showError("Error loading chat view: " + e.getMessage());
        }
    }

    @FXML
    private void handleNavigateProfile() {
        // Placeholder: Load a simple view or label
        Label profileLabel = new Label("Profile View - Not Implemented Yet");
        profileLabel.setStyle("-fx-font-size: 18px; -fx-padding: 20px;");
        if (mainPane.getScene().getRoot() instanceof BorderPane) {
            ((BorderPane) mainPane.getScene().getRoot()).setCenter(profileLabel);
        }
    }

    @FXML
    private void handleNavigateSettings() {
        // Placeholder: Load a simple view or label
        Label settingsLabel = new Label("Settings View - Not Implemented Yet");
        settingsLabel.setStyle("-fx-font-size: 18px; -fx-padding: 20px;");
        if (mainPane.getScene().getRoot() instanceof BorderPane) {
            ((BorderPane) mainPane.getScene().getRoot()).setCenter(settingsLabel);
        }
    }

    @FXML
    private void handleLogout() {
        try {
            StaticSession.setCurrentUser(null);
            Parent loginRoot = FXMLLoader
                    .load(Objects.requireNonNull(getClass().getResource("/com/example/raniaforum/auth_login.fxml")));
            mainPane.getScene().setRoot(loginRoot);
        } catch (IOException e) {
            e.printStackTrace();
            showError("Error during logout: " + e.getMessage());
        }
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Inner class for Widget Cards
    private static class WidgetCard extends HBox {
        private Label valueLabel;

        public WidgetCard(String title, String initialValue, String description, FontIcon icon) {
            super(15); // Spacing
            this.getStyleClass().add("widget-card");
            this.setAlignment(Pos.CENTER_LEFT);

            icon.getStyleClass().add("widget-icon");

            VBox textContent = new VBox(5);
            Label titleLabel = new Label(title);
            titleLabel.getStyleClass().add("widget-title");

            valueLabel = new Label(initialValue);
            valueLabel.getStyleClass().add("widget-value");

            Label descLabel = new Label(description);
            descLabel.getStyleClass().add("widget-description");

            textContent.getChildren().addAll(titleLabel, valueLabel, descLabel);
            this.getChildren().addAll(icon, textContent);
            HBox.setHgrow(textContent, Priority.ALWAYS);
        }

        public void setValue(String value) {
            this.valueLabel.setText(value);
        }
    }

    // Inner class for Forum Cards in ListView
    private class ForumCardCell extends ListCell<Forum> {
        private final BorderPane cardLayout = new BorderPane();
        private final HBox topContent = new HBox(15); // Spacing for image and main details
        private final ImageView forumImageView = new ImageView();
        private final VBox mainDetails = new VBox(5); // Title, meta, content snippet
        private final Label titleLabel = new Label();
        private final HBox metaInfoBox = new HBox(15); // Category, Author (if available), Date
        private final Label categoryLabel = new Label();
        private final Label dateLabel = new Label();
        private final Label contentSnippetLabel = new Label();

        private final HBox actionsBox = new HBox(10);
        private final Button likeButton = new Button("Like");
        private final Button commentButton = new Button("Comment");

        private final VBox commentsSection = new VBox(5);
        private final TextField commentInputField = new TextField();
        private final Button postCommentButton = new Button("Post");
        private final ListView<String> commentsListView = new ListView<>(); // Replace String with Comment model

        private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm");
        private static final int CONTENT_SNIPPET_LENGTH = 150;

        public ForumCardCell() {
            super();

            // Configure ImageView
            forumImageView.setFitHeight(100);
            forumImageView.setFitWidth(150);
            forumImageView.setPreserveRatio(false); // Can be true if you prefer
            VBox imageContainer = new VBox(forumImageView);
            imageContainer.getStyleClass().add("forum-card-image-container");
            imageContainer.setAlignment(Pos.CENTER);

            // Configure Labels
            titleLabel.getStyleClass().add("forum-card-title");
            categoryLabel.getStyleClass().add("meta-item");
            dateLabel.getStyleClass().add("meta-item");
            contentSnippetLabel.getStyleClass().add("forum-card-content-text");
            contentSnippetLabel.setWrapText(true);

            metaInfoBox.getChildren().addAll(
                    createMetaItem(new FontIcon(MaterialDesignA.APPS), categoryLabel), // Confirmed MaterialDesignA.APPS
                    createMetaItem(new FontIcon(MaterialDesignC.CALENDAR_TODAY), dateLabel)); // Confirmed
                                                                                              // MaterialDesignC.CALENDAR_TODAY

            mainDetails.getChildren().addAll(titleLabel, metaInfoBox, contentSnippetLabel);
            HBox.setHgrow(mainDetails, Priority.ALWAYS);

            topContent.getChildren().addAll(imageContainer, mainDetails);
            topContent.getStyleClass().add("forum-card"); // Use this for padding of top area

            // Configure Action Buttons
            likeButton.setGraphic(new FontIcon(MaterialDesignT.THUMB_UP_OUTLINE)); // Changed from MaterialDesignA to
                                                                                   // MaterialDesignT
            likeButton.getStyleClass().add("action-button");
            likeButton.setOnAction(e -> handleLikeAction(getItem()));

            commentButton.setGraphic(new FontIcon(MaterialDesignC.COMMENT_OUTLINE));
            commentButton.getStyleClass().add("action-button");
            commentButton.setOnAction(e -> toggleCommentsSection());

            actionsBox.getChildren().addAll(likeButton, commentButton);
            actionsBox.getStyleClass().add("forum-card-actions");

            // Configure Comments Section (initially hidden)
            commentInputField.setPromptText("Write a comment...");
            commentInputField.getStyleClass().add("comment-input-field");
            HBox.setHgrow(commentInputField, Priority.ALWAYS);

            postCommentButton.setGraphic(new FontIcon(MaterialDesignS.SEND_OUTLINE));
            postCommentButton.getStyleClass().add("comment-button");
            postCommentButton.setOnAction(e -> handlePostComment(getItem()));

            HBox commentInputBox = new HBox(5, commentInputField, postCommentButton);
            commentInputBox.setAlignment(Pos.CENTER_LEFT);

            commentsListView.setPlaceholder(new Label("No comments yet."));
            commentsListView.getStyleClass().add("comments-list-view");
            // commentsListView.setPrefHeight(100); // Adjust as needed

            commentsSection.getChildren().addAll(commentInputBox, commentsListView);
            commentsSection.getStyleClass().add("comment-section");
            commentsSection.setVisible(false); // Initially hidden
            commentsSection.setManaged(false); // So it doesn't take space when hidden

            // Layout
            VBox contentAndActions = new VBox(10, topContent, actionsBox, commentsSection);
            cardLayout.setCenter(contentAndActions);

            // Remove default padding of ListCell and add margin for spacing between cards
            setPadding(Insets.EMPTY);
            getStyleClass().add("forum-list-cell"); // For margin/effect on the cell itself
        }

        private HBox createMetaItem(FontIcon icon, Label label) {
            icon.getStyleClass().add("meta-icon");
            HBox metaItem = new HBox(5, icon, label);
            metaItem.setAlignment(Pos.CENTER_LEFT);
            return metaItem;
        }

        @Override
        protected void updateItem(Forum forum, boolean empty) {
            super.updateItem(forum, empty);
            if (empty || forum == null) {
                setText(null);
                setGraphic(null);
                if (commentsSection != null) { // Ensure commentsSection is initialized before accessing
                    commentsSection.setVisible(false);
                    commentsSection.setManaged(false);
                }
            } else {
                // Restore full card layout and updates
                titleLabel.setText(forum.getTitle());

                if (forum.getCategory() != null && forum.getCategory().getName() != null) {
                    categoryLabel.setText(forum.getCategory().getName());
                } else {
                    categoryLabel.setText("N/A");
                }

                if (forum.getCreatedAt() != null) {
                    dateLabel.setText(forum.getCreatedAt().format(formatter));
                } else {
                    dateLabel.setText("N/A");
                }

                String content = forum.getContent();
                if (content != null) {
                    contentSnippetLabel.setText(content.length() > CONTENT_SNIPPET_LENGTH
                            ? content.substring(0, CONTENT_SNIPPET_LENGTH) + "..."
                            : content);
                } else {
                    contentSnippetLabel.setText("");
                }

                // Load image
                forumImageView.setImage(null); // Reset image first
                if (forum.getImageUrl() != null && !forum.getImageUrl().isEmpty()) {
                    File imageFile = new File(IMAGE_STORAGE_DIR, forum.getImageUrl());
                    if (imageFile.exists() && imageFile.isFile()) {
                        try {
                            // Load with specific dimensions, preserve ratio, and allow background loading
                            Image image = new Image(imageFile.toURI().toString(), 150, 100, true, true);
                            forumImageView.setImage(image);
                        } catch (Exception e) {
                            // forumImageView.setImage(null); // Already null
                            System.err.println("Error loading forum image for card: " + imageFile.toURI().toString()
                                    + " - " + e.getMessage());
                        }
                    }
                }

                if (commentsSection != null) { // Ensure commentsSection is initialized
                    commentsSection.setVisible(false);
                    commentsSection.setManaged(false);
                }
                // TODO: Load existing comments for this forum if needed upon expansion
                // loadComments(forum);

                setGraphic(cardLayout); // Set the full card layout as the graphic
                setText(null); // Ensure only graphic is shown
            }
        }

        private void handleLikeAction(Forum forum) {
            if (forum == null || currentUser == null)
                return;
            // TODO: Implement like logic (backend + UI update)
            System.out.println("Liked forum: " + forum.getTitle() + " by user: " + currentUser.getNom());
            // Toggle icon
            FontIcon currentIcon = (FontIcon) likeButton.getGraphic();
            if (currentIcon.getIconCode() == MaterialDesignT.THUMB_UP_OUTLINE) { // Changed from MaterialDesignA to
                                                                                 // MaterialDesignT
                likeButton.setGraphic(new FontIcon(MaterialDesignT.THUMB_UP)); // Changed from MaterialDesignA to
                                                                               // MaterialDesignT
                likeButton.getStyleClass().add("liked");
            } else {
                likeButton.setGraphic(new FontIcon(MaterialDesignT.THUMB_UP_OUTLINE)); // Changed from MaterialDesignA
                                                                                       // to MaterialDesignT
                likeButton.getStyleClass().remove("liked");
            }
        }

        private void toggleCommentsSection() {
            boolean isVisible = commentsSection.isVisible();
            commentsSection.setVisible(!isVisible);
            commentsSection.setManaged(!isVisible);
            if (!isVisible && getItem() != null) {
                // loadComments(getItem()); // Load comments when section becomes visible
            }
        }

        private void handlePostComment(Forum forum) {
            if (forum == null || currentUser == null)
                return;
            String commentText = commentInputField.getText().trim();
            if (commentText.isEmpty()) {
                showError("Comment cannot be empty.");
                return;
            }

            System.out.println(
                    "Comment on forum '" + forum.getTitle() + "': " + commentText + " by " + currentUser.getNom());
            // Dummy add to list view for now
            commentsListView.getItems().add(currentUser.getNom() + ": " + commentText + " (Just now)");
            commentInputField.clear();
        }

    }
}
