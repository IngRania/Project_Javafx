package com.example.raniaforum.Frontend.Controllers;

import com.example.raniaforum.Backend.Models.Category;
import com.example.raniaforum.Backend.Models.Forum;
import com.example.raniaforum.Backend.Services.CategoryService;
import com.example.raniaforum.Backend.Services.ForumService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.paint.Paint;
import javafx.scene.shape.SVGPath;

import java.io.File;
import java.io.IOException; // Moved import
import java.net.URL;
import java.nio.file.Files; // Moved import
import java.nio.file.InvalidPathException; // Added import
import java.nio.file.Path; // Moved import
import java.nio.file.Paths; // Moved import
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.Optional; // Added import

public class DashboardAdminController {

    @FXML
    private BorderPane mainPane;
    @FXML
    private Label sectionTitle;
    @FXML
    private Button addButton;
    @FXML
    private StackPane contentStackPane;
    @FXML
    private VBox categoriesView;
    @FXML
    private TextField categorySearchField;
    @FXML
    private ComboBox<String> categorySortComboBox;
    @FXML
    private ListView<Category> categoryListView;
    @FXML
    private VBox forumsView;
    @FXML
    private TextField forumSearchField;
    @FXML
    private ComboBox<String> forumSortComboBox;
    @FXML
    private ListView<Forum> forumListView;

    private CategoryService categoryService;
    private ForumService forumService;

    private ObservableList<Category> masterCategoryList = FXCollections.observableArrayList();
    private FilteredList<Category> filteredCategoryList;
    private SortedList<Category> sortedCategoryList;

    private ObservableList<Forum> masterForumList = FXCollections.observableArrayList();
    private FilteredList<Forum> filteredForumList;
    private SortedList<Forum> sortedForumList;

    private enum ViewState {
        CATEGORIES,
        FORUMS
    }

    private ViewState currentState = ViewState.CATEGORIES; // Default view

    private static final String IMAGE_STORAGE_DIR = System.getProperty("user.home") + File.separator + "forum_images";

    public void initialize() {
        categoryService = new CategoryService();
        forumService = new ForumService();

        setupCategoryControls();
        setupForumControls();

        loadCategoriesData();
        loadForumsData();

        updateUIForState(); // Set initial view
    }

    private void setupCategoryControls() {
        categoryListView.setCellFactory(param -> new CategoryCardCell());
        categorySortComboBox.setItems(
                FXCollections.observableArrayList("Name (A-Z)", "Name (Z-A)", "Date (Newest)", "Date (Oldest)"));
        categorySortComboBox.setOnAction(e -> applyCategorySort());

        filteredCategoryList = new FilteredList<>(masterCategoryList, p -> true);
        categorySearchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredCategoryList.setPredicate(category -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();
                return category.getName().toLowerCase().contains(lowerCaseFilter);
            });
        });

        sortedCategoryList = new SortedList<>(filteredCategoryList);
        categoryListView.setItems(sortedCategoryList);
    }

    private void setupForumControls() {
        forumListView.setCellFactory(param -> new ForumCardCell());
        forumSortComboBox.setItems(FXCollections.observableArrayList("Title (A-Z)", "Title (Z-A)", "Date (Newest)",
                "Date (Oldest)", "Category (A-Z)"));
        forumSortComboBox.setOnAction(e -> applyForumSort());

        filteredForumList = new FilteredList<>(masterForumList, p -> true);
        forumSearchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredForumList.setPredicate(forum -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();
                if (forum.getTitle().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                }
                // Ensure category and its name are not null before checking
                return forum.getCategory() != null && forum.getCategory().getName() != null &&
                        forum.getCategory().getName().toLowerCase().contains(lowerCaseFilter);
            });
        });
        sortedForumList = new SortedList<>(filteredForumList);
        forumListView.setItems(sortedForumList);
    }

    private void applyCategorySort() {
        String sortType = categorySortComboBox.getValue();
        if (sortType == null)
            return;

        Comparator<Category> comparator = null;
        switch (sortType) {
            case "Name (A-Z)":
                comparator = Comparator.comparing(Category::getName, String.CASE_INSENSITIVE_ORDER);
                break;
            case "Name (Z-A)":
                comparator = Comparator.comparing(Category::getName, String.CASE_INSENSITIVE_ORDER).reversed();
                break;
            case "Date (Newest)":
                comparator = Comparator.comparing(Category::getCreatedAt).reversed();
                break;
            case "Date (Oldest)":
                comparator = Comparator.comparing(Category::getCreatedAt);
                break;
        }
        if (comparator != null) {
            sortedCategoryList.setComparator(comparator);
        }
    }

    private void applyForumSort() {
        String sortType = forumSortComboBox.getValue();
        if (sortType == null)
            return;

        Comparator<Forum> comparator = null;
        switch (sortType) {
            case "Title (A-Z)":
                comparator = Comparator.comparing(Forum::getTitle, String.CASE_INSENSITIVE_ORDER);
                break;
            case "Title (Z-A)":
                comparator = Comparator.comparing(Forum::getTitle, String.CASE_INSENSITIVE_ORDER).reversed();
                break;
            case "Date (Newest)":
                comparator = Comparator.comparing(Forum::getCreatedAt).reversed();
                break;
            case "Date (Oldest)":
                comparator = Comparator.comparing(Forum::getCreatedAt);
                break;
            case "Category (A-Z)":
                comparator = Comparator.comparing(
                        f -> (f.getCategory() != null && f.getCategory().getName() != null) ? f.getCategory().getName()
                                : "",
                        String.CASE_INSENSITIVE_ORDER);
                break;
        }
        if (comparator != null) {
            sortedForumList.setComparator(comparator);
        }
    }

    @FXML
    private void showCategoriesView() {
        currentState = ViewState.CATEGORIES;
        updateUIForState();
    }

    @FXML
    private void showForumsView() {
        currentState = ViewState.FORUMS;
        updateUIForState();
    }

    private void updateUIForState() {
        categoriesView.setVisible(currentState == ViewState.CATEGORIES);
        forumsView.setVisible(currentState == ViewState.FORUMS);
        if (currentState == ViewState.CATEGORIES) {
            sectionTitle.setText("Categories Management");
            addButton.setText("Add Category");
        } else {
            sectionTitle.setText("Forums Management");
            addButton.setText("Add Forum");
        }
    }

    @FXML
    private void handleAdd() {
        String fxmlFile = (currentState == ViewState.CATEGORIES) ? "add_category.fxml" : "add_forum.fxml";
        String resourcePath = "/com/example/raniaforum/" + fxmlFile;
        try {
            URL fxmlUrl = getClass().getResource(resourcePath);
            if (fxmlUrl == null) {
                showError("Cannot find FXML file: " + resourcePath);
                return;
            }
            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle((currentState == ViewState.CATEGORIES) ? "Add New Category" : "Add New Forum");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            handleRefresh();
        } catch (Exception e) {
            showError("Error opening form '" + fxmlFile + "': " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void editCategory(Category category) {
        String resourcePath = "/com/example/raniaforum/edit_category.fxml";
        try {
            URL fxmlUrl = getClass().getResource(resourcePath);
            if (fxmlUrl == null) {
                showError("Cannot find FXML file: " + resourcePath);
                return;
            }
            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();
            EditCategoryController controller = loader.getController();
            controller.setCategory(category);
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Edit Category");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            handleRefresh();
        } catch (Exception e) {
            showError("Error opening edit category form: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void editForum(Forum forum) {
        String resourcePath = "/com/example/raniaforum/edit_forum.fxml";
        try {
            URL fxmlUrl = getClass().getResource(resourcePath);
            if (fxmlUrl == null) {
                showError("Cannot find FXML file: " + resourcePath);
                return;
            }
            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();
            EditForumController controller = loader.getController();
            controller.setForum(forum);
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Edit Forum");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            handleRefresh();
        } catch (Exception e) {
            showError("Error opening edit forum form: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void deleteCategory(Category category) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Delete");
        alert.setHeaderText("Delete Category: " + category.getName());
        alert.setContentText("Are you sure you want to delete this category? This action cannot be undone.");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                categoryService.delete(category.getId());
                loadCategoriesData();
            } catch (Exception e) {
                showError("Error deleting category: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private void deleteForum(Forum forum) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Delete");
        alert.setHeaderText("Delete Forum: " + forum.getTitle());
        alert.setContentText("Are you sure you want to delete this forum? This action cannot be undone.");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                if (forum.getImageUrl() != null && !forum.getImageUrl().isEmpty()) {
                    try {
                        // Extract filename from the full path stored in getImageUrl()
                        String fileName = new File(forum.getImageUrl()).getName();
                        Path imagePath = Paths.get(IMAGE_STORAGE_DIR, fileName);
                        Files.deleteIfExists(imagePath);
                    } catch (IOException ex) {
                        System.err.println("Error deleting forum image: " + ex.getMessage());
                    } catch (InvalidPathException ex) {
                        System.err.println(
                                "Invalid path for forum image: " + forum.getImageUrl() + " - " + ex.getMessage());
                    }
                }
                forumService.delete(forum.getId());
                loadForumsData();
            } catch (Exception e) {
                showError("Error deleting forum: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void handleRefresh() {
        loadCategoriesData();
        loadForumsData();
    }

    private void loadCategoriesData() {
        try {
            masterCategoryList.setAll(categoryService.findAll());
            applyCategorySort();
        } catch (Exception e) {
            showError("Error loading categories: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void loadForumsData() {
        try {
            masterForumList.setAll(forumService.findAll());
            applyForumSort();
        } catch (Exception e) {
            showError("Error loading forums: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleChatAction() {
        String resourcePath = "/com/example/raniaforum/chat_view.fxml";
        try {
            URL fxmlUrl = getClass().getResource(resourcePath);
            if (fxmlUrl == null) {
                showError("Cannot find FXML file: " + resourcePath);
                return;
            }
            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Admin Chat");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            showError("Error opening chat: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleLogout() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Logout");
        alert.setHeaderText("Logout");
        alert.setContentText("Are you sure you want to logout?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            String resourcePath = "/com/example/raniaforum/auth_login.fxml";
            try {
                URL fxmlUrl = getClass().getResource(resourcePath);
                if (fxmlUrl == null) {
                    showError("Cannot find FXML file: " + resourcePath);
                    return;
                }
                FXMLLoader loader = new FXMLLoader(fxmlUrl);
                Parent root = loader.load();
                Stage currentStage = (Stage) sectionTitle.getScene().getWindow();
                currentStage.setScene(new Scene(root));
                currentStage.setTitle("Login - Rania Forum");
            } catch (Exception e) {
                showError("Error loading login screen: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message.replace("\\n", System.lineSeparator()));
        alert.showAndWait();
    }

    private class CategoryCardCell extends ListCell<Category> {
        private final HBox cardPane = new HBox();
        private final Label nameLabel = new Label();
        private final Label dateLabel = new Label();
        private final Button editButton = new Button();
        private final Button deleteButton = new Button();
        private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy");

        public CategoryCardCell() {
            super();
            SVGPath editIcon = new SVGPath();
            editIcon.setContent(
                    "M20.71,7.04C21.1,6.65 21.1,6.02 20.71,5.63L18.37,3.29C17.98,2.9 17.35,2.9 16.96,3.29L15.13,5.12L18.88,8.87M3,17.25V21H6.75L17.81,9.94L14.06,6.19L3,17.25Z");
            editIcon.setFill(Paint.valueOf("#4CAF50"));
            editButton.setGraphic(editIcon);
            editButton.getStyleClass().add("card-button");
            editButton.setTooltip(new Tooltip("Edit Category"));

            SVGPath deleteIcon = new SVGPath();
            deleteIcon.setContent("M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z");
            deleteIcon.setFill(Paint.valueOf("#F44336"));
            deleteButton.setGraphic(deleteIcon);
            deleteButton.getStyleClass().add("card-button");
            deleteButton.setTooltip(new Tooltip("Delete Category"));

            VBox textContent = new VBox(nameLabel, dateLabel);
            textContent.setSpacing(5);
            HBox.setHgrow(textContent, Priority.ALWAYS);

            HBox actionsPane = new HBox(editButton, deleteButton);
            actionsPane.setSpacing(10);
            actionsPane.setAlignment(javafx.geometry.Pos.CENTER_RIGHT);

            cardPane.getChildren().addAll(textContent, actionsPane);
            cardPane.setSpacing(10);
            cardPane.setPadding(new Insets(10));
            cardPane.getStyleClass().add("card-cell");

            editButton.setOnAction(e -> {
                Category category = getItem();
                if (category != null) {
                    editCategory(category);
                }
            });
            deleteButton.setOnAction(e -> {
                Category category = getItem();
                if (category != null) {
                    deleteCategory(category);
                }
            });
        }

        @Override
        protected void updateItem(Category category, boolean empty) {
            super.updateItem(category, empty);
            if (empty || category == null) {
                setText(null);
                setGraphic(null);
            } else {
                nameLabel.setText(category.getName());
                nameLabel.getStyleClass().add("card-title");
                if (category.getCreatedAt() != null) {
                    dateLabel.setText("Created: " + category.getCreatedAt().format(formatter));
                } else {
                    dateLabel.setText("Created: N/A");
                }
                dateLabel.getStyleClass().add("card-subtitle");
                setGraphic(cardPane);
            }
        }
    }

    private class ForumCardCell extends ListCell<Forum> {
        private final HBox cardPane = new HBox();
        private final ImageView forumImageView = new ImageView();
        private final Label titleLabel = new Label();
        private final Label categoryLabel = new Label();
        private final Label dateLabel = new Label();
        private final Button editButton = new Button();
        private final Button deleteButton = new Button();
        private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy");

        public ForumCardCell() {
            super();
            forumImageView.setFitHeight(60);
            forumImageView.setFitWidth(90);
            forumImageView.setPreserveRatio(true);
            forumImageView.getStyleClass().add("forum-card-image");

            SVGPath editIcon = new SVGPath();
            editIcon.setContent(
                    "M20.71,7.04C21.1,6.65 21.1,6.02 20.71,5.63L18.37,3.29C17.98,2.9 17.35,2.9 16.96,3.29L15.13,5.12L18.88,8.87M3,17.25V21H6.75L17.81,9.94L14.06,6.19L3,17.25Z");
            editIcon.setFill(Paint.valueOf("#4CAF50"));
            editButton.setGraphic(editIcon);
            editButton.getStyleClass().add("card-button");
            editButton.setTooltip(new Tooltip("Edit Forum"));

            SVGPath deleteIcon = new SVGPath();
            deleteIcon.setContent("M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z");
            deleteIcon.setFill(Paint.valueOf("#F44336"));
            deleteButton.setGraphic(deleteIcon);
            deleteButton.getStyleClass().add("card-button");
            deleteButton.setTooltip(new Tooltip("Delete Forum"));

            VBox textContent = new VBox(titleLabel, categoryLabel, dateLabel);
            textContent.setSpacing(3);
            HBox.setHgrow(textContent, Priority.ALWAYS);

            HBox actionsPane = new HBox(editButton, deleteButton);
            actionsPane.setSpacing(10);
            actionsPane.setAlignment(javafx.geometry.Pos.CENTER_RIGHT);

            cardPane.getChildren().addAll(forumImageView, textContent, actionsPane);
            cardPane.setSpacing(15);
            cardPane.setPadding(new Insets(10));
            cardPane.getStyleClass().add("card-cell");
            cardPane.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

            editButton.setOnAction(e -> {
                Forum forum = getItem();
                if (forum != null) {
                    editForum(forum);
                }
            });
            deleteButton.setOnAction(e -> {
                Forum forum = getItem();
                if (forum != null) {
                    deleteForum(forum);
                }
            });
        }

        @Override
        protected void updateItem(Forum forum, boolean empty) {
            super.updateItem(forum, empty);
            if (empty || forum == null) {
                setText(null);
                setGraphic(null);
            } else {
                titleLabel.setText(forum.getTitle());
                titleLabel.getStyleClass().add("card-title");
                if (forum.getCategory() != null && forum.getCategory().getName() != null) {
                    categoryLabel.setText("Category: " + forum.getCategory().getName());
                } else {
                    categoryLabel.setText("Category: N/A");
                }
                categoryLabel.getStyleClass().add("card-subtitle");
                if (forum.getCreatedAt() != null) {
                    dateLabel.setText("Created: " + forum.getCreatedAt().format(formatter));
                } else {
                    dateLabel.setText("Created: N/A");
                }
                dateLabel.getStyleClass().add("card-subtitle");

                if (forum.getImageUrl() != null && !forum.getImageUrl().isEmpty()) {
                    File imageFile = new File(IMAGE_STORAGE_DIR, forum.getImageUrl());
                    if (imageFile.exists() && imageFile.isFile()) {
                        try {
                            Image image = new Image(imageFile.toURI().toString());
                            forumImageView.setImage(image);
                        } catch (Exception e) {
                            forumImageView.setImage(null);
                            System.err.println("Error loading forum image for card: " + imageFile.toURI().toString()
                                    + " - " + e.getMessage());
                        }
                    } else {
                        forumImageView.setImage(null);
                    }
                } else {
                    forumImageView.setImage(null);
                }
                setGraphic(cardPane);
            }
        }
    }
}
