module com.example.raniaforum {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires java.sql;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.ikonli.materialdesign2; // Added for Material Design 2 icons
    requires org.kordamp.bootstrapfx.core;

    // Open necessary packages to javafx.fxml for reflection
    opens com.example.raniaforum to javafx.fxml;
    opens com.example.raniaforum.Frontend.Controllers to javafx.fxml;
    // If your FXML files directly reference model classes (e.g. for table columns,
    // list cells)
    // then those model packages also need to be opened.
    opens com.example.raniaforum.Backend.Models to javafx.fxml;
    // opens com.example.raniaforum.Frontend.Models to javafx.fxml; // Assuming this
    // package might be used later or exists

    // Export main application package
    exports com.example.raniaforum;

    // Export packages containing classes that need to be accessed by JavaFX (e.g.
    // controllers, models used in UI)
    exports com.example.raniaforum.Frontend.Controllers;
    exports com.example.raniaforum.Backend.Models; // Models are often needed by controllers/views
    exports com.example.raniaforum.Backend.Services; // Services might be accessed by controllers
    // exports com.example.raniaforum.Frontend.Models; // If this package contains
    // relevant classes
    // exports com.example.raniaforum.Frontend.Services; // If this package contains
    // relevant classes

}
